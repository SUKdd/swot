export type MaterialCategory = 'solid' | 'liquid' | 'gas' | 'other' | 'tag'

export interface Material {
  id: string
  name: string
  en: string
  cat: MaterialCategory
  shc?: number | null
  tc?: number | null
  temp?: number | null
  highTemp?: number | null
  highTempTo?: string | null
  lowTemp?: number | null
  lowTempTo?: string | null
  sublimate?: string | null
}

export interface BuildingPort {
  m: string
  rate: number
  temp?: number
}

export interface BuildingConverter {
  source: string
  inputs: BuildingPort[]
  outputs: BuildingPort[]
}

export interface Building {
  id: string
  name: string
  cat: string
  power: number
  powerGen: number
  selfHeat: number
  exhaustHeat: number
  converters: BuildingConverter[]
}

export interface RecipeItem {
  m: string
  kg: number
}

export interface Recipe {
  id: string
  fab: string
  fabName: string
  time: number
  in: RecipeItem[]
  out: RecipeItem[]
}

export interface Plant {
  id: string
  name: string
  en: string
  growth: number | null
  temp: string | null
  light: string | null
  atmosphere: string | null
  seedId: string | null
  irrigation: { m: string; rate: number }[]
  fertilization: { m: string; rate: number }[]
  crop: { m: string; kg: number; seconds: number } | null
  seedOnHarvest: boolean
  farmStation: boolean
  carnivore: string | null
}

export interface CritterDiet {
  eat: string[]
  out: string | null
  kcalPerKg: number | null
  conversion: number | null
}

export interface Critter {
  id: string
  name: string
  en: string
  lifespan: number | null
  adult: number | null
  temp: string | null
  diet: CritterDiet[]
  drops: { m: string; kg: number }[]
  egg: string | null
  eggMass: number | null
  eggCycles: number | null
}

export interface Food {
  id: string
  name: string
  en: string
  calories: number
  quality: number
  qualityName: string
  spoil: number | null
}

export interface Geyser {
  id: string
  name: string
  element: string
  elementName: string
  temp: number
  avg: number
  activeAvg?: number | null
  peak?: number | null
  activePct?: number | null
  note?: string | null
}

export interface Item {
  id: string
  name: string
  en: string
  cat: string
}

export type NodeKind =
  | 'building'
  | 'element'
  | 'plant'
  | 'critter'
  | 'geyser'
  | 'duplicant'
  | 'food'
  | 'item'
  | 'system'

export type MaterialRole = 'boundary' | 'supply' | 'demand'

export interface NodePort {
  id: string
  m: string
  rate: number
  temp?: number
  dir: 'in' | 'out'
}

export interface CanvasNodeData extends Record<string, unknown> {
  kind: NodeKind
  defId: string
  name: string
  category: string
  ports: NodePort[]
  count: number
  auto: boolean
  enabled: boolean
  role?: MaterialRole
  rate?: number
  temp?: number
  recipeId?: string | null
  primaryOutput?: string | null
  domestic?: boolean
  note?: string
  portsCustom?: boolean
}

export interface FlowEdgeData extends Record<string, unknown> {
  m: string
  auto?: boolean
}

export type Tool = 'pan' | 'select' | 'cut'

export type CategoryId =
  | 'buildings'
  | 'solids'
  | 'liquids'
  | 'gases'
  | 'critters'
  | 'plants'
  | 'foods'
  | 'items'
  | 'duplicants'
  | 'geysers'
  | 'rockets'
  | 'systems'
