import {
  Apple,
  Armchair,
  Atom,
  Boxes,
  Bug,
  Cpu,
  Droplets,
  Factory,
  Flame,
  FlaskConical,
  Home,
  Package,
  Radiation,
  Radio,
  Rocket,
  Sprout,
  Truck,
  Users,
  UtensilsCrossed,
  Mountain,
  Wind,
  Wrench,
  Zap,
  type LucideIcon,
} from 'lucide-react'
import type { CanvasNodeData, CategoryId, MaterialCategory } from '../lib/types'

const CATEGORY_ICON: Record<CategoryId, LucideIcon> = {
  buildings: Factory,
  solids: Boxes,
  liquids: Droplets,
  gases: Wind,
  critters: Bug,
  plants: Sprout,
  foods: UtensilsCrossed,
  items: Package,
  duplicants: Users,
  geysers: Mountain,
  rockets: Rocket,
  systems: Cpu,
}

const BUILD_ICON: Record<string, LucideIcon> = {
  电力: Zap,
  氧气: Wind,
  食物: UtensilsCrossed,
  水管: Droplets,
  通风: Wind,
  精炼: Flame,
  医疗: FlaskConical,
  火箭: Rocket,
  信号: Radio,
  运输: Truck,
  基地: Home,
  站台: FlaskConical,
  家具: Armchair,
  实用: Wrench,
  辐射: Radiation,
  其他: Boxes,
}

export function categoryIcon(id: CategoryId): LucideIcon {
  return CATEGORY_ICON[id] ?? Boxes
}

export function buildingIcon(cat: string): LucideIcon {
  return BUILD_ICON[cat] ?? Factory
}

export function nodeIcon(data: CanvasNodeData): LucideIcon {
  switch (data.kind) {
    case 'building':
      return BUILD_ICON[data.category] ?? Factory
    case 'element':
      return data.category === 'liquid'
        ? Droplets
        : data.category === 'gas'
          ? Wind
          : data.category === 'solid'
            ? Boxes
            : Atom
    case 'plant':
      return Sprout
    case 'critter':
      return Bug
    case 'geyser':
      return Mountain
    case 'duplicant':
      return Users
    case 'food':
      return Apple
    case 'item':
      return Package
    case 'system':
      if (data.defId === 'system-power') return Zap
      if (data.defId === 'system-heat') return Flame
      return Cpu
    default:
      return Boxes
  }
}

export function materialColor(cat: MaterialCategory): string {
  switch (cat) {
    case 'solid':
      return 'var(--solid)'
    case 'liquid':
      return 'var(--liquid)'
    case 'gas':
      return 'var(--gas)'
    default:
      return 'var(--other)'
  }
}

export function categoryColor(cat: string): string {
  switch (cat) {
    case '电力':
      return 'var(--power)'
    case '氧气':
    case '通风':
      return 'var(--gas)'
    case '水管':
      return 'var(--liquid)'
    case '食物':
      return 'var(--solid)'
    case '精炼':
    case '医疗':
      return 'var(--heat)'
    case '辐射':
      return 'var(--violet)'
    case '火箭':
      return 'var(--accent)'
    default:
      return 'var(--other)'
  }
}

export function KindGlyph({ data, size = 18 }: { data: CanvasNodeData; size?: number }) {
  const Icon = nodeIcon(data)
  return <Icon size={size} strokeWidth={1.8} />
}
