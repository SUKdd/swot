import { memo } from 'react'
import { BaseEdge, EdgeLabelRenderer, getBezierPath, type EdgeProps } from '@xyflow/react'
import type { CanvasEdge } from '../store'
import { useCalc } from '../components/CalcContext'
import { materialCategory, materialName } from '../lib/data'
import { materialColor } from '../components/Icon'
import { formatRate } from '../lib/format'
import { useApp } from '../store'
import { edgeFlow } from '../lib/calc'

function FlowEdgeInner({
  id,
  source,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  data,
  selected,
  markerEnd,
}: EdgeProps<CanvasEdge>) {
  const { result } = useCalc()
  const sourceNode = useApp((s) => s.nodes.find((n) => n.id === source))
  const m = data?.m ?? ''
  const color = materialColor(materialCategory(m))
  const flow = edgeFlow(sourceNode, result)
  const [path, labelX, labelY] = getBezierPath({
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    curvature: 0.3,
  })

  return (
    <>
      <BaseEdge
        id={id}
        path={path}
        markerEnd={markerEnd}
        style={{
          stroke: color,
          strokeWidth: selected ? 2.6 : 1.6,
          opacity: flow > 0 ? (selected ? 0.95 : 0.55) : 0.2,
          strokeDasharray: flow > 0 ? undefined : '4 4',
        }}
      />
      {(selected || flow > 0) && (
        <EdgeLabelRenderer>
          <div
            className={`edge-label ${selected ? 'selected' : ''}`}
            style={{
              transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)`,
              borderColor: color,
            }}
          >
            {materialName(m)} · {formatRate(flow)}
          </div>
        </EdgeLabelRenderer>
      )}
    </>
  )
}

export const FlowEdge = memo(FlowEdgeInner)
