import { useEffect } from 'react'
import { Github, X } from 'lucide-react'
import { useApp } from '../store'

export function HelpModal() {
  const open = useApp((s) => s.helpOpen)
  const setOpen = useApp((s) => s.setHelp)

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, setOpen])

  if (!open) return null

  return (
    <div className="modal-layer">
      <div className="modal-backdrop" onClick={() => setOpen(false)} />
      <div className="help-modal" role="dialog" aria-modal="true" aria-label="帮助">
        <div className="help-head">
          <div>
            <div className="eyebrow">ONI CANVAS · 使用说明</div>
            <h2>把《缺氧》的生产链摊在画布上</h2>
          </div>
          <button className="icon-btn" aria-label="关闭帮助" onClick={() => setOpen(false)}>
            <X size={18} />
          </button>
        </div>

        <div className="help-body">
          <section>
            <h3>1. 添加节点</h3>
            <p>
              点击底部分类栏（建筑、固体、液体、气体、小动物、植物、食物、物品、复制人、间歇泉、火箭、系统），
              在左侧面板里点击项目即可放到画布中心，也可以直接拖拽到指定位置。
            </p>
          </section>

          <section>
            <h3>2. 自动连线与手动连线</h3>
            <p>
              新节点会寻找最近的同种物料端口自动连线。你也可以从节点右侧的输出圆点拖到另一个节点左侧的输入圆点手动连线。
              只允许连接同种物料。使用右下角的剪刀工具，点击连线即可断开。
            </p>
          </section>

          <section>
            <h3>3. 自动计算</h3>
            <p>
              在右侧面板把节点设为“自动计算数量”，再打开顶部的“自动计算”，节点数量会按照下游消耗（以及物料边界的需求）求解。
              没有下游需求时自动节点数量为 0。物料节点可以设置为“供给”（外部上限）、“需求”（外部下限）或“平衡”（只读净值）。
            </p>
            <p className="callout">
              多产物建筑可以在右侧选择“自动计算主产物”；其余产物按实际产量记为盈余。
            </p>
          </section>

          <section>
            <h3>4. 单位约定</h3>
            <ul>
              <li>物料速率：克/秒（g/s）。一个游戏周期按 600 秒计。</li>
              <li>电力：瓦（W）；发电与耗电分开汇总。</li>
              <li>热量：千复制热/秒（kDTU/s），为建筑自身发热与排气发热之和。</li>
              <li>建筑数量可以是小数，用于表示平均开工率。</li>
            </ul>
          </section>

          <section>
            <h3>5. 快捷键</h3>
            <div className="shortcut-grid">
              <span><kbd>Delete</kbd> 删除选中</span>
              <span><kbd>Ctrl</kbd> + <kbd>Z</kbd> 撤销</span>
              <span><kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>Z</kbd> 重做</span>
              <span><kbd>Ctrl</kbd> + <kbd>S</kbd> 保存文件</span>
              <span><kbd>Esc</kbd> 关闭面板 / 取消选择</span>
              <span>滚轮 缩放 · 拖拽空白 平移</span>
            </div>
          </section>

          <section>
            <h3>6. 数据与限制</h3>
            <p>
              数据来自《缺氧》游戏数据与社区资料整理，包含 369 座建筑、405 条配方、196 种元素、35 种植物、
              104 种小动物和 30 个间歇泉。当前版本对蒸汽涡轮、泵、脱盐器等少数建筑使用了简化端口；
              小动物饲料、食物热量、压力与病菌等机制未完整建模。所有端口都可以在右侧面板手动修改。
            </p>
            <p>
              这是非官方粉丝工具，与 Klei Entertainment 无关。《缺氧》（Oxygen Not Included）及相关名称归 Klei 所有。
              本项目的代码以 MIT 协议开源；游戏数据仅用于计算与展示。
            </p>
          </section>
        </div>

        <div className="help-foot">
          <a className="btn ghost" href="https://github.com/SUKdd/oni-canvas" target="_blank" rel="noreferrer">
            <Github size={14} /> 在 GitHub 上查看
          </a>
          <button className="btn" onClick={() => setOpen(false)}>
            开始使用
          </button>
        </div>
      </div>
    </div>
  )
}
