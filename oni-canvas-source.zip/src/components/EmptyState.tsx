import { useReactFlow } from '@xyflow/react'
import { HelpCircle, MousePointerClick, Sparkles, Wand2 } from 'lucide-react'
import { useApp, type CanvasNode } from '../store'

export function EmptyState() {
  const nodes = useApp((s) => s.nodes)
  const addNode = useApp((s) => s.addNode)
  const loadExample = useApp((s) => s.loadExample)
  const setHelp = useApp((s) => s.setHelp)
  const setActiveCategory = useApp((s) => s.setActiveCategory)
  const flow = useReactFlow<CanvasNode>()

  if (nodes.length > 0) return null

  const loadExampleAndFit = () => {
    loadExample()
    setTimeout(() => flow.fitView({ padding: 0.22, duration: 400 }), 100)
  }

  const addElectrolyzer = () => {
    const center = flow.screenToFlowPosition({
      x: window.innerWidth / 2,
      y: window.innerHeight / 2,
    })
    addNode('buildings', 'Electrolyzer', { x: center.x - 110, y: center.y - 80 })
    setTimeout(() => flow.fitView({ padding: 0.35, duration: 350 }), 80)
  }

  return (
    <div className="empty-state">
      <div className="empty-glow" />
      <div className="wordmark">
        <span className="wordmark-oni">ONI</span>
        <span className="wordmark-canvas">CANVAS</span>
      </div>
      <p className="empty-kicker">缺氧计算画布</p>
      <p className="empty-sub">
        一个非官方的《缺氧》生产链计算画布。放下建筑，连线自动生成，物料、电力与热量实时平衡。
      </p>

      <div className="empty-steps">
        <div className="empty-step">
          <MousePointerClick size={17} />
          <div>
            <b>添加节点</b>
            <span>从底部分类栏选择建筑、元素或生物</span>
          </div>
        </div>
        <div className="empty-step">
          <Sparkles size={17} />
          <div>
            <b>自动连线</b>
            <span>同种物料自动接上，也可以手动拖拽端口</span>
          </div>
        </div>
        <div className="empty-step">
          <Wand2 size={17} />
          <div>
            <b>按需求解</b>
            <span>标记为“自动”的节点会按下游需求计算数量</span>
          </div>
        </div>
      </div>

      <div className="empty-actions">
        <button className="btn primary" onClick={loadExampleAndFit}>
          <Wand2 size={15} /> 加载示例
        </button>
        <button className="btn" onClick={addElectrolyzer}>
          添加电解器
        </button>
        <button className="btn ghost" onClick={() => setActiveCategory('buildings')}>
          浏览建筑
        </button>
        <button className="btn ghost" onClick={() => setHelp(true)}>
          <HelpCircle size={15} /> 帮助
        </button>
      </div>

      <p className="empty-foot">369 座建筑 · 405 条配方 · 196 种元素 · 104 种小动物</p>
    </div>
  )
}
