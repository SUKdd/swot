import { useEffect, useMemo, useState } from 'react'
import { ArrowDownLeft, ArrowUpRight, Flame, Search, X, Zap } from 'lucide-react'
import { useApp } from '../store'
import { useCalc } from './CalcContext'
import { materialCategory, materialName } from '../lib/data'
import { materialColor } from './Icon'
import { formatHeat, formatPower, formatRate, signed } from '../lib/format'

type Tab = 'materials' | 'power' | 'heat'

export function SummaryDrawer() {
  const open = useApp((s) => s.summaryOpen)
  const setOpen = useApp((s) => s.setSummary)
  const { result } = useCalc()
  const [tab, setTab] = useState<Tab>('materials')
  const [query, setQuery] = useState('')

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, setOpen])

  const materials = useMemo(() => {
    const q = query.trim().toLowerCase()
    return result.materials
      .filter((b) => {
        const any = b.produced + b.consumed + b.supply + b.demand
        if (any <= 0) return false
        if (!q) return true
        return b.m.toLowerCase().includes(q) || materialName(b.m).toLowerCase().includes(q)
      })
      .sort((a, b) => {
        if (a.net < 0 !== b.net < 0) return a.net < 0 ? -1 : 1
        return Math.abs(b.net) - Math.abs(a.net)
      })
  }, [result.materials, query])

  if (!open) return null

  return (
    <div className="drawer-layer">
      <div className="drawer-backdrop" onClick={() => setOpen(false)} />
      <aside className="drawer">
        <div className="drawer-head">
          <div>
            <h2>资源总览</h2>
            <p>物料以克/秒计，周期按 600 秒计算。</p>
          </div>
          <button className="icon-btn" aria-label="关闭总览" onClick={() => setOpen(false)}>
            <X size={18} />
          </button>
        </div>

        <div className="tabs">
          <button className={tab === 'materials' ? 'active' : ''} onClick={() => setTab('materials')}>
            物料
          </button>
          <button className={tab === 'power' ? 'active' : ''} onClick={() => setTab('power')}>
            电力
          </button>
          <button className={tab === 'heat' ? 'active' : ''} onClick={() => setTab('heat')}>
            热量
          </button>
        </div>

        {tab === 'materials' && (
          <>
            <div className="search-box drawer-search">
              <Search size={15} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="搜索物料…"
                aria-label="搜索物料"
              />
            </div>
            <div className="drawer-body">
              {materials.length === 0 ? (
                <div className="drawer-empty">还没有物料流。添加建筑或物料边界后即可看到平衡。</div>
              ) : (
                <table className="balance-table">
                  <thead>
                    <tr>
                      <th>物料</th>
                      <th>产出</th>
                      <th>消耗</th>
                      <th>边界</th>
                      <th>净流量</th>
                    </tr>
                  </thead>
                  <tbody>
                    {materials.map((b) => (
                      <tr key={b.m}>
                        <td>
                          <span className="mat-cell">
                            <i style={{ background: materialColor(materialCategory(b.m)) }} />
                            {materialName(b.m)}
                          </span>
                        </td>
                        <td className="num">{b.produced > 0 ? formatRate(b.produced, 1) : '—'}</td>
                        <td className="num">{b.consumed > 0 ? formatRate(b.consumed, 1) : '—'}</td>
                        <td className="num">
                          {b.supply > 0 && (
                            <span className="boundary supply" title="外部供给">
                              <ArrowUpRight size={11} /> {formatRate(b.supply, 1)}
                            </span>
                          )}
                          {b.demand > 0 && (
                            <span className="boundary demand" title="外部需求">
                              <ArrowDownLeft size={11} /> {formatRate(b.demand, 1)}
                            </span>
                          )}
                          {b.supply === 0 && b.demand === 0 && '—'}
                        </td>
                        <td className={`num net ${b.net < 0 ? 'neg' : b.net > 0 ? 'pos' : ''}`}>
                          {signed(b.net, 1)} g/s
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
            <div className="drawer-foot">
              净流量 = 产出 + 外部供给 − 消耗 − 外部需求。负值表示缺口，需要提高产量或降低消耗。
            </div>
          </>
        )}

        {tab === 'power' && (
          <div className="drawer-body">
            <div className="power-summary">
              <div>
                <span>
                  <Zap size={13} /> 发电
                </span>
                <b className="pos">+{formatPower(result.power.gen)}</b>
              </div>
              <div>
                <span>
                  <Zap size={13} /> 耗电
                </span>
                <b className="neg">−{formatPower(result.power.use)}</b>
              </div>
              <div className="net">
                <span>净电力</span>
                <b className={result.power.net < 0 ? 'neg' : 'pos'}>
                  {result.power.net >= 0 ? '+' : ''}
                  {formatPower(result.power.net)}
                </b>
              </div>
            </div>
            <div className="two-lists">
              <div>
                <h3>发电机</h3>
                {result.powerGen.length === 0 && <p className="muted">暂无</p>}
                {result.powerGen.map((e) => (
                  <div key={e.nodeId} className="list-row">
                    <span>{e.name}</span>
                    <b className="pos">+{formatPower(e.w)}</b>
                  </div>
                ))}
              </div>
              <div>
                <h3>用电设备</h3>
                {result.powerUse.length === 0 && <p className="muted">暂无</p>}
                {result.powerUse.map((e) => (
                  <div key={e.nodeId} className="list-row">
                    <span>{e.name}</span>
                    <b>−{formatPower(e.w)}</b>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === 'heat' && (
          <div className="drawer-body">
            <div className="power-summary">
              <div className="net">
                <span>
                  <Flame size={13} /> 总发热
                </span>
                <b>{formatHeat(result.heat)}</b>
              </div>
            </div>
            <p className="drawer-note">
              热量为建筑自身发热与排气发热之和，不含物料显热、蒸汽涡轮吸热与热传导。
            </p>
            {result.heatEntries.length === 0 && <p className="muted">暂无发热节点</p>}
            {result.heatEntries.map((e) => (
              <div key={e.nodeId} className="list-row">
                <span>{e.name}</span>
                <b>{formatHeat(e.kdtu)}</b>
              </div>
            ))}
          </div>
        )}
      </aside>
    </div>
  )
}
