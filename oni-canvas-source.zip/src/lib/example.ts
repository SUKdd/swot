import type { Edge, Node } from '@xyflow/react'
import type { CanvasNodeData, FlowEdgeData } from './types'
import {
  createBuildingNode,
  createDuplicantNode,
  createElementNode,
} from './nodeFactory'
import type { SerializedState } from './storage'

type N = Node<CanvasNodeData>
type E = Edge<FlowEdgeData>

/** A small, self-consistent demo: 4 duplicants fed by an auto-sized electrolyzer. */
export function exampleState(): SerializedState {
  const water = createElementNode('Water', { x: -40, y: 120 }, 'supply', 500)
  const electrolyzer = createBuildingNode('Electrolyzer', { x: 330, y: 90 })
  const duplicants = createDuplicantNode({ x: 720, y: 10 }, 4)
  const hydrogen = createBuildingNode('HydrogenGenerator', { x: 720, y: 300 })

  electrolyzer.data.auto = true
  electrolyzer.data.count = 1
  hydrogen.data.count = 0.5

  const nodes: N[] = [water, electrolyzer, duplicants, hydrogen]

  const edges: E[] = [
    {
      id: 'e-water-elec',
      source: water.id,
      sourceHandle: 'out',
      target: electrolyzer.id,
      targetHandle: 'in-0',
      type: 'flow',
      data: { m: 'Water', auto: true },
    },
    {
      id: 'e-elec-dup',
      source: electrolyzer.id,
      sourceHandle: 'out-0',
      target: duplicants.id,
      targetHandle: 'in-0',
      type: 'flow',
      data: { m: 'Oxygen', auto: true },
    },
    {
      id: 'e-elec-h2',
      source: electrolyzer.id,
      sourceHandle: 'out-1',
      target: hydrogen.id,
      targetHandle: 'in-0',
      type: 'flow',
      data: { m: 'Hydrogen', auto: true },
    },
  ]

  return { version: 1, nodes, edges, autoCalc: true }
}
