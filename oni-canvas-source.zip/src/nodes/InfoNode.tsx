import { memo } from 'react'
import type { NodeProps } from '@xyflow/react'
import { Flame, Zap } from 'lucide-react'
import type { CanvasNode } from '../store'
import { useCalc } from '../components/CalcContext'
import { KindGlyph } from '../components/Icon'
import { foodById, itemById } from '../lib/data'
import { formatHeat, formatPower } from '../lib/format'

function InfoNodeInner({ data, selected }: NodeProps<CanvasNode>) {
  const { result } = useCalc()
  const isPower = data.defId === 'system-power'
  const isHeat = data.defId === 'system-heat'
  const food = data.kind === 'food' ? foodById.get(data.defId) : undefined
  const item = data.kind === 'item' ? itemById.get(data.defId) : undefined

  return (
    <div className={`info-node ${selected ? 'selected' : ''}`}>
      <div className="info-head">
        <div className="node-icon">
          <KindGlyph data={data} />
        </div>
        <div className="node-heading">
          <div className="node-name">{data.name}</div>
          <div className="node-cat">{data.category}</div>
        </div>
      </div>

      {isPower && (
        <div className="readout">
          <div className="readout-main">
            <Zap size={16} />
            <span className={result.power.net < 0 ? 'neg' : 'pos'}>
              {result.power.net >= 0 ? '+' : ''}
              {formatPower(result.power.net)}
            </span>
          </div>
          <div className="readout-sub">
            发电 {formatPower(result.power.gen)} · 耗电 {formatPower(result.power.use)}
          </div>
        </div>
      )}

      {isHeat && (
        <div className="readout">
          <div className="readout-main">
            <Flame size={16} />
            <span>{formatHeat(result.heat)}</span>
          </div>
          <div className="readout-sub">{result.heatEntries.length} 个发热节点</div>
        </div>
      )}

      {food && (
        <div className="readout">
          <div className="readout-main">
            <span>{food.calories} 千卡</span>
          </div>
          <div className="readout-sub">
            品质 {food.qualityName} · 保质 {food.spoil ?? '—'} 周期
          </div>
        </div>
      )}

      {item && !food && <div className="readout-sub mono">{item.en}</div>}
      {data.note && <div className="info-note">{data.note}</div>}
    </div>
  )
}

export const InfoNode = memo(InfoNodeInner)
