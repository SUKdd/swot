import { memo } from 'react'
import { Handle, Position, type NodeProps } from '@xyflow/react'
import { Flame, Sparkles, Zap } from 'lucide-react'
import type { CanvasNode } from '../store'
import { useCalc } from '../components/CalcContext'
import { KindGlyph, categoryColor, materialColor } from '../components/Icon'
import { buildingById, materialCategory, materialName, recipesByFab } from '../lib/data'
import { formatCount, formatHeat, formatPower, formatRate } from '../lib/format'

function FlowNodeInner({ id, data, selected }: NodeProps<CanvasNode>) {
  const { result, autoCalc } = useCalc()
  const scale = result.scale[id] ?? 0
  const inputs = data.ports.filter((p) => p.dir === 'in')
  const outputs = data.ports.filter((p) => p.dir === 'out')
  const isAuto = autoCalc && data.auto && outputs.length > 0
  const def = data.kind === 'building' ? buildingById.get(data.defId) : undefined
  const hasRecipes = (recipesByFab.get(data.defId)?.length ?? 0) > 0
  const accent = categoryColor(data.category)

  const powerText =
    def && def.powerGen > 0
      ? `+${formatPower(def.powerGen * scale)}`
      : def && def.power > 0
        ? formatPower(def.power * scale)
        : null
  const heatText =
    def && def.selfHeat + def.exhaustHeat > 0
      ? formatHeat((def.selfHeat + def.exhaustHeat) * scale)
      : null

  return (
    <div
      className={`flow-node ${selected ? 'selected' : ''} ${data.enabled ? '' : 'disabled'}`}
      style={{ ['--node-accent' as string]: accent }}
    >
      <div className="node-head">
        <div className="node-icon">
          <KindGlyph data={data} />
        </div>
        <div className="node-heading">
          <div className="node-name" title={data.name}>
            {data.name}
          </div>
          <div className="node-cat">{data.category}</div>
        </div>
        <div className={`count-badge ${isAuto ? 'auto' : ''}`} title={isAuto ? '自动计算数量' : '固定数量'}>
          {isAuto && <Sparkles size={11} />}
          <span>{formatCount(scale)}</span>
        </div>
      </div>

      {data.kind === 'building' && hasRecipes && !data.recipeId && (
        <div className="node-prompt">右侧面板选择配方</div>
      )}

      {(inputs.length > 0 || outputs.length > 0) && (
        <div className="node-ports">
          {inputs.length > 0 && (
            <>
              <div className="ports-label">输入</div>
              {inputs.map((p) => {
                const deficit = (result.byMaterial[p.m]?.net ?? 0) < -1e-6
                return (
                  <div key={p.id} className={`port-row in ${deficit ? 'deficit' : ''}`}>
                    <Handle
                      type="target"
                      position={Position.Left}
                      id={p.id}
                      className="port-handle"
                      style={{ borderColor: materialColor(materialCategory(p.m)) }}
                    />
                    <span className="port-dot" style={{ background: materialColor(materialCategory(p.m)) }} />
                    <span className="port-name" title={materialName(p.m)}>{materialName(p.m)}</span>
                    <span className="port-rate">{formatRate(p.rate * scale)}</span>
                  </div>
                )
              })}
            </>
          )}
          {outputs.length > 0 && (
            <>
              <div className="ports-label out">输出</div>
              {outputs.map((p) => {
                const surplus = (result.byMaterial[p.m]?.net ?? 0) > 1e-6
                return (
                  <div key={p.id} className={`port-row out ${surplus ? 'surplus' : ''}`}>
                    <span className="port-dot" style={{ background: materialColor(materialCategory(p.m)) }} />
                    <span className="port-name" title={materialName(p.m)}>{materialName(p.m)}</span>
                    <span className="port-rate">{formatRate(p.rate * scale)}</span>
                    <Handle
                      type="source"
                      position={Position.Right}
                      id={p.id}
                      className="port-handle"
                      style={{ borderColor: materialColor(materialCategory(p.m)) }}
                    />
                  </div>
                )
              })}
            </>
          )}
        </div>
      )}

      {(powerText || heatText || data.note) && (
        <div className="node-foot">
          {powerText && (
            <span className="chip">
              <Zap size={12} /> {powerText}
            </span>
          )}
          {heatText && (
            <span className="chip">
              <Flame size={12} /> {heatText}
            </span>
          )}
          {data.note && <span className="node-note" title={data.note}>{data.note}</span>}
        </div>
      )}
    </div>
  )
}

export const FlowNode = memo(FlowNodeInner)
