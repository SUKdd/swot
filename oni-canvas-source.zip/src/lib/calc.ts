import type { Node } from '@xyflow/react'
import type { CanvasNodeData, MaterialCategory, NodePort } from './types'
import { buildingById, materialCategory } from './data'
import { buildingPowerGen as powerGenOverride } from './nodeFactory'

export interface MaterialBalance {
  m: string
  cat: MaterialCategory
  produced: number
  consumed: number
  supply: number
  demand: number
  net: number
}

export interface PowerEntry {
  nodeId: string
  name: string
  w: number
}

export interface HeatEntry {
  nodeId: string
  name: string
  kdtu: number
}

export interface CalcResult {
  scale: Record<string, number>
  materials: MaterialBalance[]
  byMaterial: Record<string, MaterialBalance>
  power: { gen: number; use: number; net: number }
  heat: number
  powerGen: PowerEntry[]
  powerUse: PowerEntry[]
  heatEntries: HeatEntry[]
  deficits: string[]
}

type FlowNode = Node<CanvasNodeData>

function hasOutputs(node: FlowNode): boolean {
  return node.data.ports.some((p) => p.dir === 'out')
}

function primaryMaterial(node: FlowNode): string | null {
  if (node.data.primaryOutput) return node.data.primaryOutput
  const outs = node.data.ports.filter((p) => p.dir === 'out')
  if (outs.length === 0) return null
  return outs.reduce((best, p) => (p.rate > best.rate ? p : best), outs[0]).m
}

function baseOutputRate(node: FlowNode, m: string): number {
  return node.data.ports
    .filter((p) => p.dir === 'out' && p.m === m)
    .reduce((sum, p) => sum + p.rate, 0)
}

interface Totals {
  produced: Record<string, number>
  consumed: Record<string, number>
  supply: Record<string, number>
  demand: Record<string, number>
}

function emptyTotals(): Totals {
  return { produced: {}, consumed: {}, supply: {}, demand: {} }
}

function add(map: Record<string, number>, key: string, value: number) {
  map[key] = (map[key] ?? 0) + value
}

function computeTotals(nodes: FlowNode[], scales: Record<string, number>): Totals {
  const t = emptyTotals()
  for (const node of nodes) {
    const d = node.data
    const scale = d.enabled ? (scales[node.id] ?? 0) : 0
    if (d.kind === 'element') {
      const rate = (d.rate ?? 0) * (d.enabled ? 1 : 0)
      if (d.role === 'supply') add(t.supply, d.defId, rate)
      if (d.role === 'demand') add(t.demand, d.defId, rate)
      continue
    }
    if (scale === 0) continue
    for (const p of d.ports) {
      if (p.dir === 'out') add(t.produced, p.m, p.rate * scale)
      else add(t.consumed, p.m, p.rate * scale)
    }
  }
  return t
}

export function calculate(nodes: FlowNode[], autoCalc: boolean): CalcResult {
  const scales: Record<string, number> = {}
  const autoCandidates: FlowNode[] = []

  for (const node of nodes) {
    const d = node.data
    if (!d.enabled) {
      scales[node.id] = 0
      continue
    }
    if (autoCalc && d.auto && hasOutputs(node) && d.kind !== 'element') {
      scales[node.id] = Math.max(0, d.count)
      autoCandidates.push(node)
    } else {
      scales[node.id] = d.count
    }
  }

  if (autoCalc && autoCandidates.length > 0) {
    for (let iter = 0; iter < 120; iter++) {
      const totals = computeTotals(nodes, scales)
      let maxDelta = 0
      for (const node of autoCandidates) {
        const m = primaryMaterial(node)
        if (!m) continue
        const base = baseOutputRate(node, m)
        if (base <= 0) continue
        const own = base * (scales[node.id] ?? 0)
        const consumed = totals.consumed[m] ?? 0
        const demand = totals.demand[m] ?? 0
        const supply = totals.supply[m] ?? 0
        const producedOthers = (totals.produced[m] ?? 0) - own
        const required = consumed + demand - supply - producedOthers
        const target = Math.max(0, required) / base
        const prev = scales[node.id] ?? 0
        const next = prev + (target - prev) * 0.55
        const clamped = Math.min(1000, Math.max(0, next))
        scales[node.id] = clamped
        maxDelta = Math.max(maxDelta, Math.abs(clamped - prev))
      }
      if (maxDelta < 1e-5) break
    }
  }

  const totals = computeTotals(nodes, scales)
  const byMaterial: Record<string, MaterialBalance> = {}
  const all = new Set<string>([
    ...Object.keys(totals.produced),
    ...Object.keys(totals.consumed),
    ...Object.keys(totals.supply),
    ...Object.keys(totals.demand),
  ])
  for (const m of all) {
    const produced = totals.produced[m] ?? 0
    const consumed = totals.consumed[m] ?? 0
    const supply = totals.supply[m] ?? 0
    const demand = totals.demand[m] ?? 0
    byMaterial[m] = {
      m,
      cat: materialCategory(m),
      produced,
      consumed,
      supply,
      demand,
      net: produced + supply - consumed - demand,
    }
  }

  const powerGen: PowerEntry[] = []
  const powerUse: PowerEntry[] = []
  const heatEntries: HeatEntry[] = []
  let heat = 0
  for (const node of nodes) {
    const d = node.data
    if (d.kind !== 'building') continue
    const def = buildingById.get(d.defId)
    if (!def) continue
    const scale = scales[node.id] ?? 0
    if (scale === 0) continue
    const gen = (powerGenOverride(d.defId) ?? def.powerGen) * scale
    const use = def.power * scale
    if (gen > 0) powerGen.push({ nodeId: node.id, name: d.name, w: gen })
    if (use > 0) powerUse.push({ nodeId: node.id, name: d.name, w: use })
    const kdtu = (def.selfHeat + def.exhaustHeat) * scale
    if (kdtu > 0) heatEntries.push({ nodeId: node.id, name: d.name, kdtu })
    heat += kdtu
  }
  powerGen.sort((a, b) => b.w - a.w)
  powerUse.sort((a, b) => b.w - a.w)
  heatEntries.sort((a, b) => b.kdtu - a.kdtu)

  const gen = powerGen.reduce((s, e) => s + e.w, 0)
  const use = powerUse.reduce((s, e) => s + e.w, 0)

  const deficits = Object.values(byMaterial)
    .filter((b) => b.net < -1e-6)
    .map((b) => b.m)

  return {
    scale: scales,
    materials: Object.values(byMaterial),
    byMaterial,
    power: { gen, use, net: gen - use },
    heat,
    powerGen,
    powerUse,
    heatEntries,
    deficits,
  }
}

export function getScale(node: FlowNode, result: CalcResult): number {
  return result.scale[node.id] ?? 0
}

export function nodePortRate(node: FlowNode, port: NodePort, result: CalcResult): number {
  return port.rate * getScale(node, result)
}

export function edgeFlow(source: FlowNode | undefined, result: CalcResult): number {
  if (!source) return 0
  const scale = getScale(source, result)
  if (source.data.kind === 'element') {
    return (source.data.rate ?? 0) * (source.data.enabled ? 1 : 0)
  }
  const out = source.data.ports.find((p) => p.dir === 'out')
  if (!out) return 0
  return out.rate * scale
}
