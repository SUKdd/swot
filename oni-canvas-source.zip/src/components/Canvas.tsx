import { useEffect, useMemo } from 'react'
import {
  Background,
  BackgroundVariant,
  ConnectionLineType,
  MarkerType,
  ReactFlow,
  SelectionMode,
  useReactFlow,
  type NodeTypes,
  type EdgeTypes,
} from '@xyflow/react'
import { useApp } from '../store'
import { FlowNode } from '../nodes/FlowNode'
import { ElementNode } from '../nodes/ElementNode'
import { InfoNode } from '../nodes/InfoNode'
import { FlowEdge } from '../nodes/FlowEdge'
import type { CategoryId } from '../lib/types'

const nodeTypes: NodeTypes = {
  flow: FlowNode,
  element: ElementNode,
  info: InfoNode,
}

const edgeTypes: EdgeTypes = {
  flow: FlowEdge,
}

export function Canvas() {
  const nodes = useApp((s) => s.nodes)
  const edges = useApp((s) => s.edges)
  const tool = useApp((s) => s.tool)
  const onNodesChange = useApp((s) => s.onNodesChange)
  const onEdgesChange = useApp((s) => s.onEdgesChange)
  const onConnect = useApp((s) => s.onConnect)
  const onNodeDragStart = useApp((s) => s.onNodeDragStart)
  const addNode = useApp((s) => s.addNode)
  const setInspector = useApp((s) => s.setInspector)
  const deleteEdge = useApp((s) => s.deleteEdge)
  const setMenu = useApp((s) => s.setMenu)
  const showToast = useApp((s) => s.showToast)
  const flow = useReactFlow()

  const defaultEdgeOptions = useMemo(
    () => ({
      type: 'flow',
      markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16, color: 'var(--edge-arrow)' },
    }),
    [],
  )

  useEffect(() => {
    if (nodes.length > 0) {
      setTimeout(() => flow.fitView({ padding: 0.25, duration: 300 }), 80)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      nodeTypes={nodeTypes}
      edgeTypes={edgeTypes}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      onConnect={onConnect}
      onNodeDragStart={onNodeDragStart}
      onNodeClick={(_, node) => setInspector(node.id)}
      onPaneClick={() => {
        setInspector(null)
        setMenu(false)
      }}
      onEdgeClick={(_, edge) => {
        if (tool === 'cut') {
          deleteEdge(edge.id)
          showToast('已断开连线')
        }
      }}
      defaultEdgeOptions={defaultEdgeOptions}
      connectionLineType={ConnectionLineType.Bezier}
      connectionLineStyle={{ stroke: 'var(--accent)', strokeWidth: 2 }}
      panOnDrag={tool === 'select' ? [1, 2] : true}
      selectionOnDrag={tool === 'select'}
      selectionMode={SelectionMode.Partial}
      deleteKeyCode={null}
      minZoom={0.15}
      maxZoom={2.5}
      fitView={false}
      proOptions={{ hideAttribution: true }}
      onDragOver={(e) => {
        e.preventDefault()
        e.dataTransfer.dropEffect = 'copy'
      }}
      onDrop={(e) => {
        e.preventDefault()
        const raw = e.dataTransfer.getData('application/oni-node')
        if (!raw) return
        try {
          const parsed = JSON.parse(raw) as { category: CategoryId; defId: string }
          const pos = flow.screenToFlowPosition({ x: e.clientX, y: e.clientY })
          addNode(parsed.category, parsed.defId, { x: pos.x - 110, y: pos.y - 50 })
        } catch {
          showToast('无法放置该项目')
        }
      }}
      className={`canvas tool-${tool}`}
    >
      <Background variant={BackgroundVariant.Dots} gap={24} size={1.3} color="var(--dots)" />
    </ReactFlow>
  )
}
