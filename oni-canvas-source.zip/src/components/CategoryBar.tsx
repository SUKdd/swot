import { useApp } from '../store'
import { CATEGORY_LIST } from '../lib/data'
import { categoryIcon } from './Icon'

export function CategoryBar() {
  const active = useApp((s) => s.activeCategory)
  const setActive = useApp((s) => s.setActiveCategory)

  return (
    <div className="category-bar" role="tablist" aria-label="节点分类">
      {CATEGORY_LIST.map((cat) => {
        const Icon = categoryIcon(cat.id)
        const isActive = active === cat.id
        return (
          <button
            key={cat.id}
            role="tab"
            aria-selected={isActive}
            className={`category-btn ${isActive ? 'active' : ''}`}
            onClick={() => setActive(isActive ? null : cat.id)}
            title={`${cat.label} (${cat.count})`}
          >
            <span className="cat-icon">
              <Icon size={19} strokeWidth={1.7} />
            </span>
            <span className="cat-label">{cat.label}</span>
            <span className="cat-count">{cat.count}</span>
          </button>
        )
      })}
    </div>
  )
}
