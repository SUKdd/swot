import { useEffect, useRef, useState } from 'react'
import { useViewport, useReactFlow, getNodesBounds, getViewportForBounds } from '@xyflow/react'
import {
  Download,
  FileJson,
  FolderOpen,
  Github,
  HelpCircle,
  Image,
  Link2,
  Menu,
  Minus,
  Moon,
  Plus,
  Sparkles,
  Sun,
  Trash2,
  Wand2,
  Zap,
} from 'lucide-react'
import { useApp, type CanvasNode } from '../store'
import { calculate } from '../lib/calc'
import { formatPower, formatRate } from '../lib/format'
import { materialCategory, materialName, SUMMARY_MATERIALS } from '../lib/data'
import { materialColor } from './Icon'
import { downloadJson, encodeShare, isValidState, serialize } from '../lib/storage'

export function TopBar() {
  const nodes = useApp((s) => s.nodes)
  const edges = useApp((s) => s.edges)
  const autoCalc = useApp((s) => s.autoCalc)
  const setAutoCalc = useApp((s) => s.setAutoCalc)
  const menuOpen = useApp((s) => s.menuOpen)
  const setMenu = useApp((s) => s.setMenu)
  const setHelp = useApp((s) => s.setHelp)
  const setSummary = useApp((s) => s.setSummary)
  const theme = useApp((s) => s.theme)
  const setTheme = useApp((s) => s.setTheme)
  const newCanvas = useApp((s) => s.newCanvas)
  const loadExample = useApp((s) => s.loadExample)
  const loadState = useApp((s) => s.loadState)
  const showToast = useApp((s) => s.showToast)
  const { zoom } = useViewport()
  const flow = useReactFlow<CanvasNode>()
  const fileRef = useRef<HTMLInputElement>(null)
  const [busy, setBusy] = useState(false)

  const result = calculate(nodes, autoCalc)

  useEffect(() => {
    if (!menuOpen) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenu(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [menuOpen, setMenu])

  const chips = SUMMARY_MATERIALS.map((m) => {
    const b = result.byMaterial[m]
    if (!b) return null
    const total = b.produced + b.consumed + b.supply + b.demand
    if (total <= 0) return null
    return b
  }).filter(Boolean)

  const stateNow = () => serialize(nodes, edges, autoCalc)

  const handleSave = () => {
    const date = new Date()
    const stamp = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`
    downloadJson(stateNow(), `oni-canvas-${stamp}.json`)
    setMenu(false)
    showToast('画布已保存到文件')
  }

  const handleOpen = async (file: File | undefined) => {
    if (!file) return
    try {
      const text = await file.text()
      const parsed = JSON.parse(text)
      if (!isValidState(parsed)) throw new Error('invalid')
      loadState(parsed, '画布已载入')
    } catch {
      showToast('无法读取该文件：不是有效的画布 JSON')
    }
    setMenu(false)
  }

  const handleShare = async () => {
    const url = encodeShare(stateNow())
    try {
      await navigator.clipboard.writeText(url)
      history.replaceState(null, '', url)
      showToast('分享链接已复制到剪贴板')
    } catch {
      history.replaceState(null, '', url)
      showToast('已写入地址栏，请手动复制')
    }
    setMenu(false)
  }

  const handlePng = async () => {
    if (nodes.length === 0) {
      showToast('画布为空，先添加一些节点吧')
      return
    }
    setBusy(true)
    try {
      const bounds = getNodesBounds(nodes)
      const width = Math.min(2600, Math.max(900, bounds.width + 220))
      const height = Math.min(2000, Math.max(600, bounds.height + 220))
      const viewport = getViewportForBounds(bounds, width, height, 0.3, 2, 0.1)
      const el = document.querySelector('.react-flow__viewport') as HTMLElement | null
      if (!el) throw new Error('missing viewport')
      const bg = getComputedStyle(document.documentElement).getPropertyValue('--bg').trim() || '#fcfcfa'
      const { toBlob } = await import('html-to-image')
      const blob = await toBlob(el, {
        backgroundColor: bg,
        width,
        height,
        style: {
          width: `${width}px`,
          height: `${height}px`,
          transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.zoom})`,
        },
        pixelRatio: 2,
        skipFonts: true,
      })
      if (!blob) throw new Error('empty image')
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'oni-canvas.png'
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 2000)
      showToast('PNG 已导出')
    } catch {
      showToast('导出 PNG 失败，请重试')
    } finally {
      setBusy(false)
      setMenu(false)
    }
  }

  return (
    <>
      <div className="topbar">
        <div className="topbar-left">
          <button
            className={`icon-btn menu-btn ${menuOpen ? 'active' : ''}`}
            aria-label="菜单"
            title="打开 / 保存 / 分享"
            onClick={() => setMenu(!menuOpen)}
          >
            <Menu size={20} />
          </button>
          <div className="brand-mini">
            <span className="brand-mark">ONI</span>
            <span className="brand-word">CANVAS</span>
          </div>
        </div>

        <div className="topbar-center" onClick={() => setSummary(true)}>
          <button className="summary-chip power-chip" title="打开资源总览">
            <Zap size={14} />
            <span className="chip-label">电力</span>
            <span className={result.power.net < 0 ? 'neg' : 'pos'}>
              {result.power.net >= 0 ? '+' : ''}
              {formatPower(result.power.net)}
            </span>
          </button>
          {chips.map((b) => (
            <button key={b!.m} className="summary-chip" title={materialName(b!.m)}>
              <span
                className="chip-dot"
                style={{ background: materialColor(materialCategory(b!.m)) }}
              />
              <span className="chip-label">{materialName(b!.m)}</span>
              <span className={b!.net < 0 ? 'neg' : b!.net > 0 ? 'pos' : ''}>
                {b!.net > 0 ? '+' : ''}
                {formatRate(b!.net, 1)}
              </span>
            </button>
          ))}
          {chips.length === 0 && <span className="summary-hint">物料与电力汇总会显示在这里</span>}
        </div>

        <div className="topbar-right">
          <label className="auto-toggle" title="自动计算：自动求解标记为“自动”的节点数量">
            <Sparkles size={14} />
            <span className="auto-label">自动计算</span>
            <input
              type="checkbox"
              checked={autoCalc}
              onChange={(e) => setAutoCalc(e.target.checked)}
            />
            <span className="switch" aria-hidden />
          </label>
          <div className="zoom-group">
            <button className="icon-btn" aria-label="缩小" onClick={() => flow.zoomOut({ duration: 150 })}>
              <Minus size={16} />
            </button>
            <button className="zoom-value" title="重置为 100%" onClick={() => flow.zoomTo(1, { duration: 200 })}>
              {Math.round(zoom * 100)}%
            </button>
            <button className="icon-btn" aria-label="放大" onClick={() => flow.zoomIn({ duration: 150 })}>
              <Plus size={16} />
            </button>
          </div>
        </div>
      </div>

      {menuOpen && (
        <>
          <div className="menu-backdrop" onClick={() => setMenu(false)} />
          <div className="app-menu" role="menu">
            <div className="menu-section">
              <button
                className="menu-item"
                onClick={() => {
                  if (nodes.length === 0 || window.confirm('新建画布会清空当前内容，继续？')) {
                    newCanvas()
                    setMenu(false)
                  }
                }}
              >
                <Trash2 size={15} /> 新建画布
              </button>
              <button className="menu-item" onClick={() => fileRef.current?.click()}>
                <FolderOpen size={15} /> 打开文件…
              </button>
              <button className="menu-item" onClick={handleSave}>
                <Download size={15} /> 保存到文件
              </button>
              <button className="menu-item" onClick={handlePng} disabled={busy}>
                <Image size={15} /> {busy ? '正在导出…' : '导出 PNG'}
              </button>
              <button className="menu-item" onClick={handleShare}>
                <Link2 size={15} /> 复制分享链接
              </button>
            </div>
            <div className="menu-sep" />
            <div className="menu-section">
              <button
                className="menu-item"
                onClick={() => {
                  if (nodes.length === 0 || window.confirm('加载示例会替换当前画布，继续？')) {
                    loadExample()
                    setMenu(false)
                    setTimeout(() => flow.fitView({ padding: 0.25, duration: 400 }), 60)
                  }
                }}
              >
                <Wand2 size={15} /> 加载示例
              </button>
              <button
                className="menu-item"
                onClick={() => {
                  setHelp(true)
                  setMenu(false)
                }}
              >
                <HelpCircle size={15} /> 帮助与快捷键
              </button>
              <button
                className="menu-item"
                onClick={() => {
                  setTheme(theme === 'dark' ? 'light' : 'dark')
                  setMenu(false)
                }}
              >
                {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
                {theme === 'dark' ? '切换浅色主题' : '切换深色主题'}
              </button>
            </div>
            <div className="menu-sep" />
            <div className="menu-section">
              <a
                className="menu-item"
                href="https://github.com/SUKdd/oni-canvas"
                target="_blank"
                rel="noreferrer"
              >
                <Github size={15} /> GitHub 仓库
              </a>
              <a className="menu-item" href="https://www.klei.com/" target="_blank" rel="noreferrer">
                <FileJson size={15} /> Klei / 缺氧官网
              </a>
            </div>
            <div className="menu-foot">非官方粉丝工具 · 数据来自游戏与社区整理</div>
          </div>
        </>
      )}

      <input
        ref={fileRef}
        type="file"
        accept="application/json,.json"
        hidden
        onChange={(e) => {
          void handleOpen(e.target.files?.[0])
          e.target.value = ''
        }}
      />
    </>
  )
}
