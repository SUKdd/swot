import { useEffect, useMemo } from 'react'
import { ReactFlowProvider } from '@xyflow/react'
import { useApp } from './store'
import { calculate } from './lib/calc'
import { CalcProvider } from './components/CalcContext'
import { Canvas } from './components/Canvas'
import { TopBar } from './components/TopBar'
import { CategoryBar } from './components/CategoryBar'
import { AddPanel } from './components/AddPanel'
import { Inspector } from './components/Inspector'
import { SummaryDrawer } from './components/SummaryDrawer'
import { HelpModal } from './components/HelpModal'
import { EmptyState } from './components/EmptyState'
import { ToolDock, Toast } from './components/Tools'
import { downloadJson, saveLocal, serialize } from './lib/storage'

function isTyping(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false
  const tag = target.tagName.toLowerCase()
  return tag === 'input' || tag === 'textarea' || tag === 'select' || target.isContentEditable
}

function AppInner() {
  const nodes = useApp((s) => s.nodes)
  const edges = useApp((s) => s.edges)
  const autoCalc = useApp((s) => s.autoCalc)
  const undo = useApp((s) => s.undo)
  const redo = useApp((s) => s.redo)
  const deleteSelection = useApp((s) => s.deleteSelection)
  const setInspector = useApp((s) => s.setInspector)
  const setMenu = useApp((s) => s.setMenu)
  const setSummary = useApp((s) => s.setSummary)
  const setHelp = useApp((s) => s.setHelp)
  const setActiveCategory = useApp((s) => s.setActiveCategory)

  const result = useMemo(() => calculate(nodes, autoCalc), [nodes, autoCalc])
  const ctx = useMemo(() => ({ result, autoCalc }), [result, autoCalc])

  useEffect(() => {
    const t = setTimeout(() => saveLocal(serialize(nodes, edges, autoCalc)), 350)
    return () => clearTimeout(t)
  }, [nodes, edges, autoCalc])

  useEffect(() => {
    if (window.location.hash.startsWith('#s=')) {
      history.replaceState(null, '', window.location.pathname + window.location.search)
    }
  }, [])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey
      if (mod && e.key.toLowerCase() === 's') {
        e.preventDefault()
        const date = new Date()
        const stamp = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`
        downloadJson(serialize(nodes, edges, autoCalc), `oni-canvas-${stamp}.json`)
        return
      }
      if (isTyping(e.target)) return
      if (e.key === 'Escape') {
        setInspector(null)
        setMenu(false)
        setSummary(false)
        setHelp(false)
        setActiveCategory(null)
        return
      }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault()
        deleteSelection()
        return
      }
      if (mod && e.key.toLowerCase() === 'z') {
        e.preventDefault()
        if (e.shiftKey) redo()
        else undo()
        return
      }
      if (mod && e.key.toLowerCase() === 'y') {
        e.preventDefault()
        redo()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [
    nodes,
    edges,
    autoCalc,
    undo,
    redo,
    deleteSelection,
    setInspector,
    setMenu,
    setSummary,
    setHelp,
    setActiveCategory,
  ])

  return (
    <CalcProvider value={ctx}>
      <div className="app-shell">
        <Canvas />
        <EmptyState />
        <TopBar />
        <CategoryBar />
        <AddPanel />
        <Inspector />
        <ToolDock />
        <SummaryDrawer />
        <HelpModal />
        <Toast />
      </div>
    </CalcProvider>
  )
}

export default function App() {
  return (
    <ReactFlowProvider>
      <AppInner />
    </ReactFlowProvider>
  )
}
