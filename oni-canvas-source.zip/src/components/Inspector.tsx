import { Copy, Flame, Info, Plus, RotateCcw, Sparkles, Trash2, X, Zap } from 'lucide-react'
import { useApp } from '../store'
import { useCalc } from './CalcContext'
import { KindGlyph, materialColor } from './Icon'
import {
  buildingById,
  critterById,
  foodById,
  gasMaterials,
  geyserById,
  itemById,
  liquidMaterials,
  materialById,
  materialCategory,
  materialName,
  materials,
  plantById,
  recipesByFab,
  solidMaterials,
} from '../lib/data'
import { buildingNote, buildingPowerGen } from '../lib/nodeFactory'
import { formatCount, formatHeat, formatPower, formatRate, signed } from '../lib/format'
import type { Material } from '../lib/types'

const MATERIAL_GROUPS = [
  { label: '固体', list: solidMaterials },
  { label: '液体', list: liquidMaterials },
  { label: '气体', list: gasMaterials },
  {
    label: '标签与其他',
    list: materials.filter((m) => m.cat === 'tag' || m.cat === 'other'),
  },
]

const STATE_LABEL: Record<string, string> = {
  solid: '固体',
  liquid: '液体',
  gas: '气体',
  other: '特殊',
  tag: '标签',
}

function MaterialOptions() {
  return (
    <>
      {MATERIAL_GROUPS.map((g) => (
        <optgroup key={g.label} label={g.label}>
          {g.list.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name}
            </option>
          ))}
        </optgroup>
      ))}
    </>
  )
}

function switchRow(
  label: string,
  checked: boolean,
  onChange: (v: boolean) => void,
  hint?: string,
) {
  return (
    <label className="switch-row">
      <span className="switch-text">
        <span>{label}</span>
        {hint && <small>{hint}</small>}
      </span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <i className="toggle" aria-hidden />
    </label>
  )
}

function MaterialFacts({ mat }: { mat: Material }) {
  const kToC = (k: number | null | undefined) =>
    k == null ? null : Math.round((k - 273.15) * 100) / 100
  return (
    <dl className="kv">
      <div>
        <dt>物态</dt>
        <dd>{STATE_LABEL[mat.cat] ?? mat.cat}</dd>
      </div>
      {mat.shc != null && (
        <div>
          <dt>比热容</dt>
          <dd>{mat.shc} DTU/(g·°C)</dd>
        </div>
      )}
      {mat.tc != null && (
        <div>
          <dt>导热率</dt>
          <dd>{mat.tc}</dd>
        </div>
      )}
      {mat.temp != null && (
        <div>
          <dt>默认温度</dt>
          <dd>{kToC(mat.temp)}°C</dd>
        </div>
      )}
      {mat.highTemp != null && mat.highTempTo && (
        <div>
          <dt>高温相变</dt>
          <dd>
            {kToC(mat.highTemp)}°C → {materialName(mat.highTempTo)}
          </dd>
        </div>
      )}
      {mat.lowTemp != null && mat.lowTempTo && (
        <div>
          <dt>低温相变</dt>
          <dd>
            {kToC(mat.lowTemp)}°C → {materialName(mat.lowTempTo)}
          </dd>
        </div>
      )}
      {mat.sublimate && (
        <div>
          <dt>升华</dt>
          <dd>{materialName(mat.sublimate)}</dd>
        </div>
      )}
    </dl>
  )
}

export function Inspector() {
  const nodes = useApp((s) => s.nodes)
  const inspectorId = useApp((s) => s.inspectorId)
  const setInspector = useApp((s) => s.setInspector)
  const patchNode = useApp((s) => s.patchNode)
  const setRecipe = useApp((s) => s.setRecipe)
  const setDomestic = useApp((s) => s.setDomestic)
  const setRole = useApp((s) => s.setRole)
  const editPort = useApp((s) => s.editPort)
  const addPort = useApp((s) => s.addPort)
  const removePort = useApp((s) => s.removePort)
  const resetPorts = useApp((s) => s.resetPorts)
  const deleteNode = useApp((s) => s.deleteNode)
  const duplicateNode = useApp((s) => s.duplicateNode)
  const { result, autoCalc } = useCalc()

  const node = nodes.find((n) => n.id === inspectorId)
  if (!node) return null
  const d = node.data
  const scale = result.scale[node.id] ?? 0
  const def = d.kind === 'building' ? buildingById.get(d.defId) : undefined
  const plant = d.kind === 'plant' ? plantById.get(d.defId) : undefined
  const critter = d.kind === 'critter' ? critterById.get(d.defId) : undefined
  const geyser = d.kind === 'geyser' ? geyserById.get(d.defId) : undefined
  const food = d.kind === 'food' ? foodById.get(d.defId) : undefined
  const item = d.kind === 'item' ? itemById.get(d.defId) : undefined
  const mat = d.kind === 'element' ? materialById.get(d.defId) : undefined
  const recipes = d.kind === 'building' ? (recipesByFab.get(d.defId) ?? []) : []
  const canAuto =
    d.kind !== 'element' &&
    d.kind !== 'duplicant' &&
    d.kind !== 'food' &&
    d.kind !== 'item' &&
    d.kind !== 'system' &&
    d.ports.some((p) => p.dir === 'out')
  const outMats = Array.from(new Set(d.ports.filter((p) => p.dir === 'out').map((p) => p.m)))
  const unit =
    d.kind === 'plant'
      ? '棵'
      : d.kind === 'critter'
        ? '只'
        : d.kind === 'duplicant'
          ? '人'
          : d.kind === 'geyser'
            ? '座'
            : d.kind === 'building'
              ? '台'
              : '个'
  const powerGenOverride = d.kind === 'building' ? buildingPowerGen(d.defId) : undefined
  const powerGen = def ? (powerGenOverride ?? def.powerGen) : 0

  return (
    <aside className="inspector" aria-label="节点设置">
      <div className="inspector-head">
        <div className="node-icon">
          <KindGlyph data={d} />
        </div>
        <div className="inspector-title">
          <h2>{d.name}</h2>
          <span className="inspector-sub">
            {d.category} · {d.defId}
          </span>
        </div>
        <button className="icon-btn" aria-label="关闭设置" onClick={() => setInspector(null)}>
          <X size={16} />
        </button>
      </div>

      <div className="inspector-body">
        {d.kind !== 'element' &&
          d.kind !== 'food' &&
          d.kind !== 'item' &&
          d.kind !== 'system' && (
            <section className="section">
              <div className="field-row">
                <label>数量</label>
                <div className="stepper">
                  <button
                    aria-label="减少"
                    onClick={() =>
                      patchNode(node.id, {
                        count: Math.max(0, Math.round((d.count - 1) * 100) / 100),
                      })
                    }
                  >
                    −
                  </button>
                  <input
                    type="number"
                    min={0}
                    step={0.1}
                    value={d.count}
                    onChange={(e) => {
                      const v = Number(e.target.value)
                      if (Number.isFinite(v)) patchNode(node.id, { count: Math.max(0, v) })
                    }}
                  />
                  <span className="unit">{unit}</span>
                  <button
                    aria-label="增加"
                    onClick={() =>
                      patchNode(node.id, { count: Math.round((d.count + 1) * 100) / 100 })
                    }
                  >
                    +
                  </button>
                </div>
              </div>

              {canAuto && (
                <div className="auto-solve-box">
                  {switchRow('自动计算数量', d.auto, (v) => patchNode(node.id, { auto: v }), '按下游需求求解')}
                  {autoCalc && d.auto && (
                    <div className="solved-line">
                      <Sparkles size={13} /> 求解结果：<b>{formatCount(scale)}</b> {unit}
                    </div>
                  )}
                  {autoCalc && d.auto && scale === 0 && (
                    <div className="hint">没有下游需求或供给约束时，自动节点为 0。</div>
                  )}
                </div>
              )}

              {switchRow('启用节点', d.enabled, (v) => patchNode(node.id, { enabled: v }))}
            </section>
          )}

        {d.kind === 'element' && (
          <section className="section">
            <div className="section-head">
              <h3>物料边界</h3>
            </div>
            <div className="segmented">
              {(
                [
                  ['boundary', '平衡'],
                  ['supply', '供给'],
                  ['demand', '需求'],
                ] as const
              ).map(([role, label]) => (
                <button
                  key={role}
                  className={d.role === role ? 'active' : ''}
                  onClick={() => setRole(node.id, role)}
                >
                  {label}
                </button>
              ))}
            </div>
            <p className="hint">
              供给表示外部上限，需求表示外部下限；平衡只显示当前净流量，不改变平衡。
            </p>
            {d.role !== 'boundary' && (
              <div className="field-row">
                <label>速率</label>
                <div className="input-with-unit">
                  <input
                    type="number"
                    min={0}
                    step={10}
                    value={d.rate ?? 0}
                    onChange={(e) => {
                      const v = Number(e.target.value)
                      if (Number.isFinite(v)) patchNode(node.id, { rate: Math.max(0, v) })
                    }}
                  />
                  <span>g/s</span>
                </div>
              </div>
            )}
            <div className="field-row">
              <label>温度</label>
              <div className="input-with-unit">
                <input
                  type="number"
                  step={1}
                  value={d.temp ?? 20}
                  onChange={(e) => {
                    const v = Number(e.target.value)
                    if (Number.isFinite(v)) patchNode(node.id, { temp: v })
                  }}
                />
                <span>°C</span>
              </div>
            </div>
            {mat && <MaterialFacts mat={mat} />}
            <div className="balance-line">
              当前净流量：
              <b className={(result.byMaterial[d.defId]?.net ?? 0) < 0 ? 'neg' : 'pos'}>
                {signed(result.byMaterial[d.defId]?.net ?? 0, 2)} g/s
              </b>
            </div>
          </section>
        )}

        {d.kind === 'building' && def && (
          <section className="section">
            <div className="section-head">
              <h3>建筑</h3>
              <span className="mini-tag">{def.cat}</span>
            </div>
            {recipes.length > 0 && (
              <div className="field-col">
                <label>作业配方</label>
                <select
                  value={d.recipeId ?? ''}
                  onChange={(e) => setRecipe(node.id, e.target.value || null)}
                >
                  <option value="">
                    {def.converters.length > 0 ? '默认建筑转化' : '未选择配方（暂无物料流）'}
                  </option>
                  {recipes.map((r) => {
                    const ins = r.in.map((o) => `${materialName(o.m)}×${o.kg}kg`).join(' + ')
                    const outs = r.out.map((o) => `${materialName(o.m)}×${o.kg}kg`).join(' + ')
                    return (
                      <option key={r.id} value={r.id}>
                        {ins} → {outs} · {r.time}s
                      </option>
                    )
                  })}
                </select>
                <p className="hint">切换配方会重建端口；已失去端口的连线会被移除。</p>
              </div>
            )}
            {autoCalc && d.auto && outMats.length > 1 && (
              <div className="field-col">
                <label>自动计算主产物</label>
                <select
                  value={d.primaryOutput ?? outMats[0]}
                  onChange={(e) => patchNode(node.id, { primaryOutput: e.target.value })}
                >
                  {outMats.map((m) => (
                    <option key={m} value={m}>
                      {materialName(m)}
                    </option>
                  ))}
                </select>
                <p className="hint">副产物不计入求解目标，会在总览中显示为盈余。</p>
              </div>
            )}
            <div className="stat-grid">
              <div>
                <span>
                  <Zap size={12} /> 耗电
                </span>
                <b>{formatPower(def.power * scale)}</b>
              </div>
              <div>
                <span>
                  <Zap size={12} /> 发电
                </span>
                <b>{formatPower(powerGen * scale)}</b>
              </div>
              <div>
                <span>
                  <Flame size={12} /> 发热
                </span>
                <b>{formatHeat((def.selfHeat + def.exhaustHeat) * scale)}</b>
              </div>
            </div>
            {buildingNote(d.defId) && <p className="hint">{buildingNote(d.defId)}</p>}
          </section>
        )}

        {d.kind === 'plant' && plant && (
          <section className="section">
            <div className="section-head">
              <h3>植物</h3>
              <span className="mini-tag">生长 {plant.growth ?? '—'} 周期</span>
            </div>
            {(plant.irrigation.length > 0 || plant.fertilization.length > 0) && (
              <div className="field-col">
                {switchRow('栽培模式', d.domestic ?? false, (v) => setDomestic(node.id, v), '关闭后不消耗灌溉与肥料')}
              </div>
            )}
            <dl className="kv">
              <div>
                <dt>温度范围</dt>
                <dd>{plant.temp ?? '不限'}</dd>
              </div>
              <div>
                <dt>光照</dt>
                <dd>{plant.light === 'no' ? '不需要' : (plant.light ?? '不限')}</dd>
              </div>
              {plant.atmosphere && (
                <div>
                  <dt>环境</dt>
                  <dd>{plant.atmosphere}</dd>
                </div>
              )}
              {plant.crop && (
                <div>
                  <dt>收获</dt>
                  <dd>
                    {materialName(plant.crop.m)} ×{plant.crop.kg}kg / {plant.crop.seconds}s
                  </dd>
                </div>
              )}
              {plant.farmStation && (
                <div>
                  <dt>农业站</dt>
                  <dd>可受农业站加成</dd>
                </div>
              )}
            </dl>
          </section>
        )}

        {d.kind === 'critter' && critter && (
          <section className="section">
            <div className="section-head">
              <h3>小动物</h3>
              <span className="mini-tag">寿命 {critter.lifespan ?? '—'} 周期</span>
            </div>
            <dl className="kv">
              <div>
                <dt>成年周期</dt>
                <dd>{critter.adult ?? '—'}</dd>
              </div>
              <div>
                <dt>温度</dt>
                <dd>{critter.temp ?? '不限'}</dd>
              </div>
              {critter.drops.map((x) => (
                <div key={x.m}>
                  <dt>屠宰产出</dt>
                  <dd>
                    {materialName(x.m)} ×{x.kg}kg
                  </dd>
                </div>
              ))}
            </dl>
            {critter.diet.length > 0 && (
              <div className="diet-list">
                <div className="diet-title">饮食（资料）</div>
                {critter.diet.map((x, i) => (
                  <div key={i} className="diet-line">
                    <span>{x.eat.slice(0, 4).map(materialName).join(' / ')}</span>
                    <span>→ {x.out ? materialName(x.out) : '—'}</span>
                  </div>
                ))}
              </div>
            )}
            <p className="hint">
              当前版本把屠宰产出按寿命折算进物料平衡；饲料消耗与环境需求尚未计入，适合做产出规划而非完整牧场模拟。
            </p>
          </section>
        )}

        {d.kind === 'geyser' && geyser && (
          <section className="section">
            <div className="section-head">
              <h3>间歇泉</h3>
              <span className="mini-tag">{geyser.temp}°C</span>
            </div>
            <dl className="kv">
              <div>
                <dt>平均产量</dt>
                <dd>{formatRate(geyser.avg, 1)}</dd>
              </div>
              {geyser.activeAvg != null && (
                <div>
                  <dt>喷发期平均</dt>
                  <dd>{formatRate(geyser.activeAvg, 1)}</dd>
                </div>
              )}
              {geyser.peak != null && (
                <div>
                  <dt>峰值</dt>
                  <dd>{formatRate(geyser.peak, 1)}</dd>
                </div>
              )}
              {geyser.activePct != null && (
                <div>
                  <dt>活跃占比</dt>
                  <dd>{geyser.activePct}%</dd>
                </div>
              )}
              <div>
                <dt>元素</dt>
                <dd>{materialName(geyser.element)}</dd>
              </div>
            </dl>
            {geyser.note && <p className="hint">{geyser.note}</p>}
          </section>
        )}

        {d.kind === 'duplicant' && (
          <section className="section">
            <div className="section-head">
              <h3>复制人需求</h3>
            </div>
            <dl className="kv">
              <div>
                <dt>氧气</dt>
                <dd>100 g/s / 人</dd>
              </div>
              <div>
                <dt>二氧化碳</dt>
                <dd>2 g/s / 人</dd>
              </div>
              <div>
                <dt>食物</dt>
                <dd>1000 kcal/周期 / 人（资料）</dd>
              </div>
            </dl>
            <p className="hint">食物与压力等机制未进入物料平衡；复制人节点作为氧气需求的锚点。</p>
          </section>
        )}

        {d.kind === 'food' && food && (
          <section className="section">
            <div className="section-head">
              <h3>食物资料</h3>
            </div>
            <dl className="kv">
              <div>
                <dt>热量</dt>
                <dd>{food.calories} 千卡</dd>
              </div>
              <div>
                <dt>品质</dt>
                <dd>{food.qualityName}</dd>
              </div>
              <div>
                <dt>保质期</dt>
                <dd>{food.spoil ?? '—'} 周期</dd>
              </div>
              <div>
                <dt>英文名</dt>
                <dd>{food.en}</dd>
              </div>
            </dl>
            <p className="hint">食物节点是资料卡，不参与物料平衡。烹饪链可在建筑的配方中选择。</p>
          </section>
        )}

        {d.kind === 'item' && item && (
          <section className="section">
            <div className="section-head">
              <h3>物品资料</h3>
              <span className="mini-tag">{item.cat === 'equipment' ? '装备' : '物品'}</span>
            </div>
            <dl className="kv">
              <div>
                <dt>英文名</dt>
                <dd>{item.en}</dd>
              </div>
              <div>
                <dt>ID</dt>
                <dd className="mono">{item.id}</dd>
              </div>
            </dl>
          </section>
        )}

        {d.kind === 'system' && (
          <section className="section">
            <div className="section-head">
              <h3>系统读数</h3>
            </div>
            {d.defId === 'system-power' && (
              <dl className="kv">
                <div>
                  <dt>净电力</dt>
                  <dd className={result.power.net < 0 ? 'neg' : 'pos'}>
                    {result.power.net >= 0 ? '+' : ''}
                    {formatPower(result.power.net)}
                  </dd>
                </div>
                <div>
                  <dt>总发电</dt>
                  <dd>{formatPower(result.power.gen)}</dd>
                </div>
                <div>
                  <dt>总耗电</dt>
                  <dd>{formatPower(result.power.use)}</dd>
                </div>
              </dl>
            )}
            {d.defId === 'system-heat' && (
              <dl className="kv">
                <div>
                  <dt>总发热</dt>
                  <dd>{formatHeat(result.heat)}</dd>
                </div>
                <div>
                  <dt>发热节点</dt>
                  <dd>{result.heatEntries.length}</dd>
                </div>
              </dl>
            )}
            {d.note && <p className="hint">{d.note}</p>}
          </section>
        )}

        {d.ports.length > 0 && (
          <section className="section">
            <div className="section-head">
              <h3>物料端口</h3>
              {(d.kind === 'building' || d.kind === 'plant') && (
                <button className="mini-btn" onClick={() => resetPorts(node.id)}>
                  <RotateCcw size={12} /> 重置
                </button>
              )}
            </div>
            <div className="port-editor">
              {d.ports.map((p) => (
                <div className="port-edit" key={p.id}>
                  <span className={`dir-pill ${p.dir}`}>{p.dir === 'in' ? '入' : '出'}</span>
                  <select
                    value={p.m}
                    onChange={(e) => editPort(node.id, p.id, { m: e.target.value })}
                    aria-label="物料"
                  >
                    <MaterialOptions />
                  </select>
                  <input
                    type="number"
                    min={0}
                    step={0.1}
                    value={Number(p.rate.toFixed(3))}
                    onChange={(e) => {
                      const v = Number(e.target.value)
                      if (Number.isFinite(v)) editPort(node.id, p.id, { rate: v })
                    }}
                    aria-label="速率"
                  />
                  <span className="port-unit">g/s</span>
                  <button
                    className="icon-btn tiny"
                    aria-label="删除端口"
                    onClick={() => removePort(node.id, p.id)}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
              <div className="port-actions">
                <button className="mini-btn" onClick={() => addPort(node.id, 'in')}>
                  <Plus size={12} /> 输入
                </button>
                <button className="mini-btn" onClick={() => addPort(node.id, 'out')}>
                  <Plus size={12} /> 输出
                </button>
              </div>
              <p className="hint">端口数值是“每台/每棵/每只”的基准速率；修改物料会断开该端口上的连线。</p>
            </div>
          </section>
        )}

        {d.kind !== 'element' && d.kind !== 'food' && d.kind !== 'item' && d.kind !== 'system' && (
          <section className="section balance-section">
            <div className="section-head">
              <h3>本节点的收支</h3>
            </div>
            {d.ports.length === 0 && <p className="hint">暂无物料端口。</p>}
            {d.ports.map((p) => {
              const net = result.byMaterial[p.m]?.net ?? 0
              return (
                <div key={p.id} className="balance-row">
                  <span className="balance-name">
                    <i style={{ background: materialColor(materialCategory(p.m)) }} />
                    {materialName(p.m)}
                  </span>
                  <span className={p.dir === 'in' ? 'neg' : 'pos'}>
                    {p.dir === 'in' ? '−' : '+'}
                    {formatRate(p.rate * scale)}
                  </span>
                  <span className={`balance-global ${net < 0 ? 'neg' : 'pos'}`} title="该物料在全画布的净流量">
                    全域 {signed(net, 1)}
                  </span>
                </div>
              )
            })}
          </section>
        )}

        {d.note && d.kind !== 'building' && d.kind !== 'plant' && d.kind !== 'critter' && (
          <p className="inspector-note">
            <Info size={13} /> {d.note}
          </p>
        )}
      </div>

      <div className="inspector-foot">
        <button className="btn ghost" onClick={() => duplicateNode(node.id)}>
          <Copy size={14} /> 复制
        </button>
        <button className="btn danger" onClick={() => deleteNode(node.id)}>
          <Trash2 size={14} /> 删除
        </button>
      </div>
    </aside>
  )
}
