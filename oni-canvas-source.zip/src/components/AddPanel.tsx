import { useMemo, useState } from 'react'
import { useReactFlow } from '@xyflow/react'
import { Search, X } from 'lucide-react'
import { useApp, type CanvasNode } from '../store'
import {
  buildings,
  buildingCategories,
  CATEGORY_LIST,
  critters,
  foods,
  geysers,
  items,
  liquidMaterials,
  materialById,
  materialName,
  plants,
  rocketBuildings,
  solidMaterials,
  gasMaterials,
} from '../lib/data'
import { SYSTEM_DEFS } from '../lib/nodeFactory'
import { categoryIcon, buildingIcon, materialColor } from './Icon'
import { formatPower, formatRate } from '../lib/format'
import type { CategoryId } from '../lib/types'

interface AddItem {
  id: string
  name: string
  meta: string
  accent?: string
  icon?: ReturnType<typeof categoryIcon>
  sub?: string
}

function tempC(k: number | null | undefined): string | null {
  if (k == null) return null
  return `${Math.round((k - 273.15) * 10) / 10}°C`
}

function itemsFor(category: CategoryId): AddItem[] {
  switch (category) {
    case 'buildings':
      return buildings.map((b) => ({
        id: b.id,
        name: b.name,
        meta:
          b.powerGen > 0
            ? `+${formatPower(b.powerGen)}`
            : b.power > 0
              ? `${formatPower(b.power)}`
              : b.converters.length > 0
                ? '转化'
                : '—',
        sub: b.cat,
        icon: buildingIcon(b.cat),
      }))
    case 'rockets':
      return rocketBuildings.map((b) => ({
        id: b.id,
        name: b.name,
        meta: b.power > 0 ? formatPower(b.power) : '火箭',
        sub: b.cat,
        icon: buildingIcon(b.cat),
      }))
    case 'solids':
      return solidMaterials.map((m) => ({
        id: m.id,
        name: m.name,
        meta: tempC(m.temp) ?? '固体',
        accent: materialColor('solid'),
      }))
    case 'liquids':
      return liquidMaterials.map((m) => ({
        id: m.id,
        name: m.name,
        meta: tempC(m.temp) ?? '液体',
        accent: materialColor('liquid'),
      }))
    case 'gases':
      return gasMaterials.map((m) => ({
        id: m.id,
        name: m.name,
        meta: tempC(m.temp) ?? '气体',
        accent: materialColor('gas'),
      }))
    case 'critters':
      return critters.map((c) => ({
        id: c.id,
        name: c.name,
        meta: c.lifespan ? `${c.lifespan} 周期` : '小动物',
        sub: c.temp ?? undefined,
        icon: categoryIcon('critters'),
      }))
    case 'plants':
      return plants.map((p) => ({
        id: p.id,
        name: p.name,
        meta: p.growth ? `${p.growth} 周期` : '植物',
        sub: p.temp ?? undefined,
        icon: categoryIcon('plants'),
      }))
    case 'foods':
      return foods.map((f) => ({
        id: f.id,
        name: f.name,
        meta: `${f.calories} 千卡`,
        sub: f.qualityName,
        icon: categoryIcon('foods'),
      }))
    case 'items':
      return items.map((it) => ({
        id: it.id,
        name: it.name,
        meta: it.cat === 'equipment' ? '装备' : '物品',
        icon: categoryIcon('items'),
      }))
    case 'duplicants':
      return [
        {
          id: 'duplicant',
          name: '复制人',
          meta: '100 g/s 氧气',
          sub: '1000 kcal/周期',
          icon: categoryIcon('duplicants'),
        },
      ]
    case 'geysers':
      return geysers.map((g) => ({
        id: g.id,
        name: g.name,
        meta: formatRate(g.avg, 0),
        sub: `${g.temp}°C · ${materialName(g.element)}`,
        accent: materialColor(materialById.get(g.element)?.cat ?? 'other'),
      }))
    case 'systems':
      return SYSTEM_DEFS.map((s) => ({
        id: s.id,
        name: s.name,
        meta: '系统',
        sub: s.description,
        icon: categoryIcon('systems'),
      }))
  }
}

export function AddPanel() {
  const active = useApp((s) => s.activeCategory)
  const setActive = useApp((s) => s.setActiveCategory)
  const addNode = useApp((s) => s.addNode)
  const nodes = useApp((s) => s.nodes)
  const [query, setQuery] = useState('')
  const [sub, setSub] = useState<string>('全部')
  const flow = useReactFlow<CanvasNode>()

  const meta = CATEGORY_LIST.find((c) => c.id === active)

  const list = useMemo(() => {
    if (!active) return []
    let all = itemsFor(active)
    if (active === 'buildings' && sub !== '全部') {
      all = all.filter((i) => i.sub === sub)
    }
    if (active === 'items') {
      if (sub === '装备') all = all.filter((i) => i.meta === '装备')
      if (sub === '物品') all = all.filter((i) => i.meta === '物品')
    }
    const q = query.trim().toLowerCase()
    if (q) {
      all = all.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          i.id.toLowerCase().includes(q) ||
          (i.sub ?? '').toLowerCase().includes(q),
      )
    }
    return all.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'))
  }, [active, query, sub])

  if (!active || !meta) return null

  const place = (defId: string) => {
    const center = flow.screenToFlowPosition({
      x: window.innerWidth / 2,
      y: window.innerHeight / 2,
    })
    const base = { x: center.x - 110, y: center.y - 90 }
    let spot = base
    for (let i = 0; i < 24; i += 1) {
      const hit = nodes.some(
        (n) =>
          Math.abs(n.position.x - spot.x) < 276 &&
          Math.abs(n.position.y - spot.y) < 196,
      )
      if (!hit) break
      const ring = Math.floor(i / 4) + 1
      const angle = ((i % 4) * Math.PI) / 2 + Math.PI / 4
      spot = {
        x: base.x + Math.cos(angle) * 220 * ring,
        y: base.y + Math.sin(angle) * 150 * ring,
      }
    }
    addNode(active, defId, spot)
  }

  const subs =
    active === 'buildings'
      ? ['全部', ...buildingCategories]
      : active === 'items'
        ? ['全部', '物品', '装备']
        : []

  return (
    <aside className="add-panel" aria-label={`${meta.label}面板`}>
      <div className="panel-head">
        <div className="panel-title">
          <span>{meta.label}</span>
          <span className="panel-count">{meta.count}</span>
        </div>
        <button className="icon-btn" aria-label="关闭" onClick={() => setActive(null)}>
          <X size={16} />
        </button>
      </div>

      <div className="search-box">
        <Search size={15} />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="搜索名称或 ID…"
          aria-label="搜索"
        />
        {query && (
          <button className="clear-btn" aria-label="清空搜索" onClick={() => setQuery('')}>
            <X size={13} />
          </button>
        )}
      </div>

      {subs.length > 0 && (
        <div className="sub-chips">
          {subs.map((s) => (
            <button
              key={s}
              className={`sub-chip ${sub === s ? 'active' : ''}`}
              onClick={() => setSub(s)}
            >
              {s}
            </button>
          ))}
        </div>
      )}

      <div className="panel-hint">点击放到画布中心，或拖拽到画布上的指定位置</div>

      <div className="add-grid">
        {list.map((item) => {
          const Icon = item.icon
          return (
            <button
              key={item.id}
              className="add-tile"
              draggable
              onDragStart={(e) => {
                e.dataTransfer.setData(
                  'application/oni-node',
                  JSON.stringify({ category: active, defId: item.id }),
                )
                e.dataTransfer.effectAllowed = 'copy'
              }}
              onClick={() => place(item.id)}
              title={`${item.name}${item.sub ? ` · ${item.sub}` : ''}`}
            >
              <span
                className="tile-icon"
                style={item.accent ? { color: item.accent, borderColor: item.accent } : undefined}
              >
                {Icon ? <Icon size={16} /> : <span className="tile-dot" style={{ background: item.accent }} />}
              </span>
              <span className="tile-text">
                <span className="tile-name">{item.name}</span>
                <span className="tile-meta">{item.meta}</span>
              </span>
            </button>
          )
        })}
        {list.length === 0 && <div className="panel-empty">没有匹配的项目</div>}
      </div>

      <div className="panel-foot">
        共 {list.length} 项
        {active === 'buildings' && list.length !== buildings.length ? ` / ${buildings.length}` : ''}
      </div>
    </aside>
  )
}
