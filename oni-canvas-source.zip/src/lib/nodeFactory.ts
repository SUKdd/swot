import type { Node } from '@xyflow/react'
import type { CanvasNodeData, CategoryId, MaterialRole, NodePort } from './types'
import {
  buildingById,
  critterById,
  foods as allFoods,
  geyserById,
  items as allItems,
  materialById,
  plantById,
  recipeById,
} from './data'

let seq = 0
export function newId(prefix = 'n'): string {
  seq += 1
  const rnd =
    typeof crypto !== 'undefined' && 'randomUUID' in crypto
      ? crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10)
  return `${prefix}-${rnd}-${seq}`
}

interface Override {
  inputs?: { m: string; rate: number; temp?: number }[]
  outputs?: { m: string; rate: number; temp?: number }[]
  note?: string
  powerGen?: number
}

const PORT_OVERRIDES: Record<string, Override> = {
  SteamTurbine2: {
    inputs: [{ m: 'Steam', rate: 2000, temp: 125 }],
    outputs: [{ m: 'Water', rate: 2000, temp: 95 }],
    note: '简化模型：按满负荷 2 kg/s 蒸汽计算，实际吞吐随蒸汽温度变化。',
  },
  LiquidPump: {
    outputs: [{ m: 'Water', rate: 10000 }],
    note: '默认输出水，可在右侧面板把端口改成任意液体。',
  },
  LiquidMiniPump: {
    outputs: [{ m: 'Water', rate: 1000 }],
    note: '默认输出水，可在右侧面板把端口改成任意液体。',
  },
  GasPump: {
    outputs: [{ m: 'Oxygen', rate: 500 }],
    note: '默认输出氧气，可在右侧面板把端口改成任意气体。',
  },
  GasMiniPump: {
    outputs: [{ m: 'Oxygen', rate: 50 }],
    note: '默认输出氧气，可在右侧面板把端口改成任意气体。',
  },
  Desalinator: {
    inputs: [{ m: 'SaltWater', rate: 5000 }],
    outputs: [
      { m: 'Water', rate: 4650 },
      { m: 'Salt', rate: 350 },
    ],
    note: '简化模型：仅列出盐水制淡水路线；浓盐水路线可在端口面板编辑。',
  },
  PowerTransformer: { powerGen: 0, note: '变压器只限流，不计入发电。' },
  PowerTransformerSmall: { powerGen: 0, note: '变压器只限流，不计入发电。' },
}

function makePorts(
  ports: { m: string; rate: number; temp?: number }[],
  dir: 'in' | 'out',
): NodePort[] {
  return ports.map((p, i) => ({
    id: `${dir}-${i}`,
    m: p.m,
    rate: p.rate,
    temp: p.temp,
    dir,
  }))
}

export function buildingPorts(defId: string, recipeId?: string | null): NodePort[] {
  const override = PORT_OVERRIDES[defId]
  if (recipeId) {
    const r = recipeById.get(recipeId)
    if (r) {
      const t = r.time > 0 ? r.time : 1
      return [
        ...makePorts(r.in.map((x) => ({ m: x.m, rate: (x.kg * 1000) / t })), 'in'),
        ...makePorts(r.out.map((x) => ({ m: x.m, rate: (x.kg * 1000) / t })), 'out'),
      ]
    }
  }
  const def = buildingById.get(defId)
  const convIn: { m: string; rate: number; temp?: number }[] = []
  const convOut: { m: string; rate: number; temp?: number }[] = []
  if (def) {
    for (const cv of def.converters) {
      convIn.push(...cv.inputs)
      convOut.push(...cv.outputs)
    }
  }
  if (convIn.length === 0 && convOut.length === 0 && override) {
    return [
      ...makePorts(override.inputs ?? [], 'in'),
      ...makePorts(override.outputs ?? [], 'out'),
    ]
  }
  return [...makePorts(convIn, 'in'), ...makePorts(convOut, 'out')]
}

export function defaultPrimaryOutput(ports: NodePort[]): string | null {
  const outs = ports.filter((p) => p.dir === 'out')
  if (outs.length === 0) return null
  return outs.reduce((best, p) => (p.rate > best.rate ? p : best), outs[0]).m
}

export function buildingNote(defId: string): string | undefined {
  return PORT_OVERRIDES[defId]?.note
}

export function buildingPowerGen(defId: string): number | undefined {
  return PORT_OVERRIDES[defId]?.powerGen
}

export function createBuildingNode(
  defId: string,
  position: { x: number; y: number },
  recipeId?: string | null,
): Node<CanvasNodeData> {
  const def = buildingById.get(defId)
  if (!def) throw new Error(`unknown building ${defId}`)
  const chosenRecipe = recipeId ?? null
  const ports = buildingPorts(defId, chosenRecipe)
  return {
    id: newId('b'),
    type: 'flow',
    position,
    data: {
      kind: 'building',
      defId,
      name: def.name,
      category: def.cat,
      ports,
      count: 1,
      auto: false,
      enabled: true,
      recipeId: chosenRecipe,
      primaryOutput: defaultPrimaryOutput(ports),
      note: buildingNote(defId),
    },
  }
}

export function createElementNode(
  materialId: string,
  position: { x: number; y: number },
  role: MaterialRole = 'boundary',
  rate = 0,
): Node<CanvasNodeData> {
  const mat = materialById.get(materialId)
  const defaultC = mat?.temp != null ? Math.round((mat.temp - 273.15) * 10) / 10 : 20
  return {
    id: newId('e'),
    type: 'element',
    position,
    data: {
      kind: 'element',
      defId: materialId,
      name: mat?.name ?? materialId,
      category: mat?.cat ?? 'other',
      ports: [],
      count: 1,
      auto: false,
      enabled: true,
      role,
      rate,
      temp: defaultC,
    },
  }
}

export function plantPorts(plantId: string, domestic: boolean): NodePort[] {
  const p = plantById.get(plantId)
  if (!p) return []
  const ins: { m: string; rate: number }[] = []
  if (domestic) {
    ins.push(...p.irrigation.map((x) => ({ m: x.m, rate: x.rate })))
    ins.push(...p.fertilization.map((x) => ({ m: x.m, rate: x.rate })))
  }
  const outs: { m: string; rate: number }[] = []
  if (p.crop && p.crop.seconds > 0) {
    outs.push({ m: p.crop.m, rate: (p.crop.kg * 1000) / p.crop.seconds })
  }
  return [...makePorts(ins, 'in'), ...makePorts(outs, 'out')]
}

export function createPlantNode(
  plantId: string,
  position: { x: number; y: number },
): Node<CanvasNodeData> {
  const p = plantById.get(plantId)
  if (!p) throw new Error(`unknown plant ${plantId}`)
  const domestic = p.irrigation.length + p.fertilization.length > 0
  const ports = plantPorts(plantId, domestic)
  return {
    id: newId('p'),
    type: 'flow',
    position,
    data: {
      kind: 'plant',
      defId: plantId,
      name: p.name,
      category: '植物',
      ports,
      count: 1,
      auto: false,
      enabled: true,
      domestic,
      primaryOutput: defaultPrimaryOutput(ports),
      note: p.growth ? `生长周期 ${p.growth} 周期` : undefined,
    },
  }
}

export function createCritterNode(
  critterId: string,
  position: { x: number; y: number },
): Node<CanvasNodeData> {
  const c = critterById.get(critterId)
  if (!c) throw new Error(`unknown critter ${critterId}`)
  const lifespan = c.lifespan && c.lifespan > 0 ? c.lifespan : 100
  const outs = c.drops.map((d, i) => ({
    id: `out-${i}`,
    m: d.m,
    rate: (d.kg * 1000) / (lifespan * 600),
    dir: 'out' as const,
  }))
  return {
    id: newId('c'),
    type: 'flow',
    position,
    data: {
      kind: 'critter',
      defId: critterId,
      name: c.name,
      category: '小动物',
      ports: outs,
      count: 1,
      auto: false,
      enabled: true,
      note: '产出按寿命平均折算；饲料与环境需求未计入物料平衡。',
    },
  }
}

export function createGeyserNode(
  geyserId: string,
  position: { x: number; y: number },
): Node<CanvasNodeData> {
  const g = geyserById.get(geyserId)
  if (!g) throw new Error(`unknown geyser ${geyserId}`)
  return {
    id: newId('g'),
    type: 'flow',
    position,
    data: {
      kind: 'geyser',
      defId: geyserId,
      name: g.name,
      category: '间歇泉',
      ports: [{ id: 'out-0', m: g.element, rate: g.avg, temp: g.temp, dir: 'out' }],
      count: 1,
      auto: false,
      enabled: true,
      note: `平均 ${g.avg.toFixed(1)} g/s · ${g.temp}°C`,
    },
  }
}

export function createDuplicantNode(
  position: { x: number; y: number },
  count = 1,
): Node<CanvasNodeData> {
  return {
    id: newId('d'),
    type: 'flow',
    position,
    data: {
      kind: 'duplicant',
      defId: 'duplicant',
      name: '复制人',
      category: '复制人',
      ports: [
        { id: 'in-0', m: 'Oxygen', rate: 100, dir: 'in' },
        { id: 'out-0', m: 'CarbonDioxide', rate: 2, dir: 'out' },
      ],
      count,
      auto: false,
      enabled: true,
      note: '氧气 100 g/s · 食物 1000 kcal/周期（食物未计入物料平衡）',
    },
  }
}

export function createFoodNode(
  foodId: string,
  position: { x: number; y: number },
): Node<CanvasNodeData> {
  const f = allFoods.find((x) => x.id === foodId)
  return {
    id: newId('f'),
    type: 'info',
    position,
    data: {
      kind: 'food',
      defId: foodId,
      name: f?.name ?? foodId,
      category: '食物',
      ports: [],
      count: 1,
      auto: false,
      enabled: true,
      note: f
        ? `${f.calories} 千卡 · 品质 ${f.qualityName} · 保质 ${f.spoil ?? '—'} 周期`
        : undefined,
    },
  }
}

export function createItemNode(
  itemId: string,
  position: { x: number; y: number },
): Node<CanvasNodeData> {
  const it = allItems.find((x) => x.id === itemId)
  return {
    id: newId('i'),
    type: 'info',
    position,
    data: {
      kind: 'item',
      defId: itemId,
      name: it?.name ?? itemId,
      category: it?.cat === 'equipment' ? '装备' : '物品',
      ports: [],
      count: 1,
      auto: false,
      enabled: true,
    },
  }
}

export interface SystemDef {
  id: string
  name: string
  description: string
  kind: 'readout' | 'element' | 'duplicant'
  materialId?: string
  role?: MaterialRole
  rate?: number
  count?: number
}

export const SYSTEM_DEFS: SystemDef[] = [
  {
    id: 'system-power',
    name: '电力核算',
    description: '显示整张画布的净电力，不参与物料平衡。',
    kind: 'readout',
  },
  {
    id: 'system-heat',
    name: '热量核算',
    description: '汇总整张画布的发热量。',
    kind: 'readout',
  },
  {
    id: 'system-oxygen',
    name: '氧气需求',
    description: '氧气需求边界，默认 1000 g/s。',
    kind: 'element',
    materialId: 'Oxygen',
    role: 'demand',
    rate: 1000,
  },
  {
    id: 'system-duplicant',
    name: '复制人 × 8',
    description: '一次放置 8 名复制人的氧气与二氧化碳收支。',
    kind: 'duplicant',
    count: 8,
  },
]

export function createSystemNode(
  systemId: string,
  position: { x: number; y: number },
): Node<CanvasNodeData> {
  const def = SYSTEM_DEFS.find((s) => s.id === systemId)
  if (!def) throw new Error(`unknown system ${systemId}`)
  if (def.kind === 'element' && def.materialId) {
    return createElementNode(def.materialId, position, def.role ?? 'demand', def.rate ?? 0)
  }
  if (def.kind === 'duplicant') {
    return createDuplicantNode(position, def.count ?? 1)
  }
  return {
    id: newId('s'),
    type: 'info',
    position,
    data: {
      kind: 'system',
      defId: def.id,
      name: def.name,
      category: '系统',
      ports: [],
      count: 1,
      auto: false,
      enabled: true,
      note: def.description,
    },
  }
}

export function createNodeForCategory(
  category: CategoryId,
  defId: string,
  position: { x: number; y: number },
): Node<CanvasNodeData> {
  switch (category) {
    case 'buildings':
    case 'rockets':
      return createBuildingNode(defId, position)
    case 'solids':
    case 'liquids':
    case 'gases':
      return createElementNode(defId, position)
    case 'plants':
      return createPlantNode(defId, position)
    case 'critters':
      return createCritterNode(defId, position)
    case 'geysers':
      return createGeyserNode(defId, position)
    case 'foods':
      return createFoodNode(defId, position)
    case 'items':
      return createItemNode(defId, position)
    case 'duplicants':
      return createDuplicantNode(position)
    case 'systems':
      return createSystemNode(defId, position)
  }
}
