import { create } from 'zustand'
import {
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
  type Connection,
  type Edge,
  type EdgeChange,
  type Node,
  type NodeChange,
} from '@xyflow/react'
import type {
  CanvasNodeData,
  CategoryId,
  FlowEdgeData,
  MaterialRole,
  NodePort,
  Tool,
} from './lib/types'
import {
  buildingPorts,
  createNodeForCategory,
  defaultPrimaryOutput,
  newId,
  plantPorts,
} from './lib/nodeFactory'
import { bootState, type SerializedState } from './lib/storage'
import { exampleState } from './lib/example'

export type CanvasNode = Node<CanvasNodeData>
export type CanvasEdge = Edge<FlowEdgeData>

interface Snapshot {
  nodes: CanvasNode[]
  edges: CanvasEdge[]
}

interface AppState {
  nodes: CanvasNode[]
  edges: CanvasEdge[]
  autoCalc: boolean
  activeCategory: CategoryId | null
  inspectorId: string | null
  tool: Tool
  helpOpen: boolean
  summaryOpen: boolean
  menuOpen: boolean
  theme: 'light' | 'dark'
  toast: string | null
  past: Snapshot[]
  future: Snapshot[]

  onNodesChange: (changes: NodeChange<CanvasNode>[]) => void
  onEdgesChange: (changes: EdgeChange<CanvasEdge>[]) => void
  onConnect: (connection: Connection) => void
  onNodeDragStart: () => void

  addNode: (category: CategoryId, defId: string, position: { x: number; y: number }) => void
  patchNode: (id: string, patch: Partial<CanvasNodeData>, commit?: boolean) => void
  replacePorts: (id: string, ports: NodePort[]) => void
  editPort: (id: string, portId: string, patch: { m?: string; rate?: number }) => void
  addPort: (id: string, dir: 'in' | 'out') => void
  removePort: (id: string, portId: string) => void
  resetPorts: (id: string) => void
  setRecipe: (id: string, recipeId: string | null) => void
  setDomestic: (id: string, domestic: boolean) => void
  setRole: (id: string, role: MaterialRole) => void
  deleteNode: (id: string) => void
  deleteEdge: (id: string) => void
  deleteSelection: () => void
  duplicateNode: (id: string) => void

  setAutoCalc: (v: boolean) => void
  setActiveCategory: (c: CategoryId | null) => void
  setInspector: (id: string | null) => void
  setTool: (t: Tool) => void
  setHelp: (v: boolean) => void
  setSummary: (v: boolean) => void
  setMenu: (v: boolean) => void
  setTheme: (t: 'light' | 'dark') => void
  showToast: (text: string) => void

  undo: () => void
  redo: () => void
  newCanvas: () => void
  loadExample: () => void
  loadState: (state: SerializedState, toast?: string) => void
  snapshot: () => void
}

const boot = bootState()
const initialTheme: 'light' | 'dark' =
  typeof document !== 'undefined' && document.documentElement.dataset.theme === 'dark'
    ? 'dark'
    : 'light'

let toastTimer: ReturnType<typeof setTimeout> | null = null

function portForHandle(
  node: CanvasNode,
  handleId: string | null | undefined,
): { id: string; m: string; dir: 'in' | 'out' } | null {
  if (!handleId) return null
  const d = node.data
  if (d.kind === 'element') {
    if (handleId === 'out' && d.role !== 'demand') {
      return { id: 'out', m: d.defId, dir: 'out' }
    }
    if (handleId === 'in' && d.role !== 'supply') {
      return { id: 'in', m: d.defId, dir: 'in' }
    }
    return null
  }
  const p = d.ports.find((x) => x.id === handleId)
  return p ? { id: p.id, m: p.m, dir: p.dir } : null
}

function distance(a: CanvasNode, b: CanvasNode): number {
  return Math.hypot(a.position.x - b.position.x, a.position.y - b.position.y)
}

function makeEdge(
  source: CanvasNode,
  sourceHandle: string,
  target: CanvasNode,
  targetHandle: string,
  m: string,
): CanvasEdge {
  return {
    id: `e-${source.id}-${sourceHandle}-${target.id}-${targetHandle}`,
    source: source.id,
    sourceHandle,
    target: target.id,
    targetHandle,
    type: 'flow',
    data: { m, auto: true },
  }
}

function autoConnectFor(
  node: CanvasNode,
  existing: CanvasNode[],
  currentEdges: CanvasEdge[],
): CanvasEdge[] {
  const created: CanvasEdge[] = []
  const d = node.data
  const newPorts: { id: string; m: string; dir: 'in' | 'out' }[] =
    d.kind === 'element'
      ? d.role === 'supply'
        ? [{ id: 'out', m: d.defId, dir: 'out' }]
        : d.role === 'demand'
          ? [{ id: 'in', m: d.defId, dir: 'in' }]
          : []
      : d.ports.map((p) => ({ id: p.id, m: p.m, dir: p.dir }))

  const taken = new Set(
    currentEdges.map((e) => `${e.source}|${e.sourceHandle}|${e.target}|${e.targetHandle}`),
  )

  for (const port of newPorts) {
    const candidates = existing
      .map((other) => {
        const opposite = other.data.ports.filter(
          (p) => p.m === port.m && p.dir !== port.dir,
        )
        const elementPort =
          other.data.kind === 'element' && other.data.defId === port.m
            ? other.data.role === 'supply' && port.dir === 'in'
              ? [{ id: 'out', m: port.m, dir: 'out' as const }]
              : other.data.role === 'demand' && port.dir === 'out'
                ? [{ id: 'in', m: port.m, dir: 'in' as const }]
                : []
            : []
        return { node: other, ports: [...opposite, ...elementPort] }
      })
      .filter((c) => c.ports.length > 0)
      .sort((a, b) => distance(node, a.node) - distance(node, b.node))

    const best = candidates[0]
    if (!best) continue
    const otherPort = best.ports[0]
    const source = port.dir === 'out' ? node : best.node
    const sourceHandle = port.dir === 'out' ? port.id : otherPort.id
    const target = port.dir === 'out' ? best.node : node
    const targetHandle = port.dir === 'out' ? otherPort.id : port.id
    const key = `${source.id}|${sourceHandle}|${target.id}|${targetHandle}`
    if (taken.has(key)) continue
    taken.add(key)
    created.push(makeEdge(source, sourceHandle, target, targetHandle, port.m))
  }
  return created
}

function pruneEdgesForNode(edges: CanvasEdge[], node: CanvasNode): CanvasEdge[] {
  const d = node.data
  if (d.kind === 'element') {
    return edges.filter((e) => {
      if (e.source === node.id) return d.role !== 'demand'
      if (e.target === node.id) return d.role !== 'supply'
      return true
    })
  }
  const outIds = new Set(d.ports.filter((p) => p.dir === 'out').map((p) => p.id))
  const inIds = new Set(d.ports.filter((p) => p.dir === 'in').map((p) => p.id))
  return edges.filter((e) => {
    if (e.source === node.id) return outIds.has(e.sourceHandle ?? '')
    if (e.target === node.id) return inIds.has(e.targetHandle ?? '')
    return true
  })
}

function cloneNodes(nodes: CanvasNode[]): CanvasNode[] {
  return nodes.map((n) => ({
    ...n,
    position: { ...n.position },
    data: { ...n.data, ports: n.data.ports.map((p) => ({ ...p })) },
  }))
}

function normalizePrimary(
  primary: string | null | undefined,
  ports: NodePort[],
): string | null {
  const outs = ports.filter((p) => p.dir === 'out')
  if (primary && outs.some((p) => p.m === primary)) return primary
  if (outs.length === 0) return null
  return outs.reduce((best, p) => (p.rate > best.rate ? p : best), outs[0]).m
}

function connectFresh(
  id: string,
  get: () => AppState,
  set: (partial: Partial<AppState>) => void,
) {
  const { nodes, edges } = get()
  const node = nodes.find((n) => n.id === id)
  if (!node) return
  const created = autoConnectFor(
    node,
    nodes.filter((n) => n.id !== id),
    edges,
  )
  if (created.length > 0) set({ edges: [...edges, ...created] })
}

export const useApp = create<AppState>((set, get) => ({
  nodes: boot?.nodes ?? [],
  edges: boot?.edges ?? [],
  autoCalc: boot?.autoCalc ?? true,
  activeCategory: null,
  inspectorId: null,
  tool: 'pan',
  helpOpen: false,
  summaryOpen: false,
  menuOpen: false,
  theme: initialTheme,
  toast: null,
  past: [],
  future: [],

  snapshot: () => {
    const { nodes, edges, past } = get()
    set({
      past: [...past, { nodes: cloneNodes(nodes), edges: edges.map((e) => ({ ...e })) }].slice(-60),
      future: [],
    })
  },

  onNodesChange: (changes) => {
    const removed = changes.some((c) => c.type === 'remove')
    if (removed) get().snapshot()
    set({ nodes: applyNodeChanges(changes, get().nodes) })
    if (removed) {
      const ids = new Set(get().nodes.map((n) => n.id))
      set({
        edges: get().edges.filter((e) => ids.has(e.source) && ids.has(e.target)),
        inspectorId:
          get().inspectorId && ids.has(get().inspectorId!) ? get().inspectorId : null,
      })
    }
  },

  onEdgesChange: (changes) => {
    const removed = changes.some((c) => c.type === 'remove')
    if (removed) get().snapshot()
    set({ edges: applyEdgeChanges(changes, get().edges) })
  },

  onNodeDragStart: () => {
    get().snapshot()
  },

  onConnect: (connection) => {
    const { nodes, edges } = get()
    const source = nodes.find((n) => n.id === connection.source)
    const target = nodes.find((n) => n.id === connection.target)
    if (!source || !target || source.id === target.id) return
    const sp = portForHandle(source, connection.sourceHandle)
    const tp = portForHandle(target, connection.targetHandle)
    if (!sp || !tp) return
    if (sp.dir !== 'out' || tp.dir !== 'in') {
      get().showToast('请从输出端口连到输入端口')
      return
    }
    if (sp.m !== tp.m) {
      get().showToast('只能连接同种物料')
      return
    }
    const id = `e-${source.id}-${sp.id}-${target.id}-${tp.id}`
    if (edges.some((e) => e.id === id)) return
    get().snapshot()
    set({
      edges: addEdge(
        {
          id,
          source: source.id,
          sourceHandle: sp.id,
          target: target.id,
          targetHandle: tp.id,
          type: 'flow',
          data: { m: sp.m, auto: false },
        },
        edges,
      ),
    })
  },

  addNode: (category, defId, position) => {
    get().snapshot()
    const node = createNodeForCategory(category, defId, position)
    const { nodes, edges } = get()
    const newEdges = autoConnectFor(node, nodes, edges)
    set({
      nodes: [...nodes, node],
      edges: [...edges, ...newEdges],
      inspectorId: node.id,
    })
  },

  patchNode: (id, patch, commit = false) => {
    if (commit) get().snapshot()
    const { nodes, edges } = get()
    let updated: CanvasNode | null = null
    const next = nodes.map((n) => {
      if (n.id !== id) return n
      const merged = { ...n.data, ...patch }
      if (patch.ports && patch.primaryOutput === undefined) {
        merged.primaryOutput = normalizePrimary(merged.primaryOutput, merged.ports)
      }
      updated = { ...n, data: merged }
      return updated
    })
    set({
      nodes: next,
      edges: updated ? pruneEdgesForNode(edges, updated) : edges,
    })
  },

  replacePorts: (id, ports) => {
    get().patchNode(
      id,
      {
        ports,
        portsCustom: true,
        primaryOutput: normalizePrimary(
          get().nodes.find((n) => n.id === id)?.data.primaryOutput,
          ports,
        ),
      },
      true,
    )
  },

  setRecipe: (id, recipeId) => {
    const node = get().nodes.find((n) => n.id === id)
    if (!node || node.data.kind !== 'building') return
    const ports = buildingPorts(node.data.defId, recipeId)
    get().patchNode(
      id,
      { recipeId, ports, portsCustom: false, primaryOutput: defaultPrimaryOutput(ports) },
      true,
    )
    connectFresh(id, get, set)
  },

  editPort: (id, portId, patch) => {
    const node = get().nodes.find((n) => n.id === id)
    if (!node) return
    const ports = node.data.ports.map((p) =>
      p.id === portId
        ? {
            ...p,
            ...(patch.m != null ? { m: patch.m } : {}),
            ...(patch.rate != null && Number.isFinite(patch.rate)
              ? { rate: Math.max(0, patch.rate) }
              : {}),
          }
        : p,
    )
    const next: CanvasNode = {
      ...node,
      data: {
        ...node.data,
        ports,
        portsCustom: true,
        primaryOutput: normalizePrimary(node.data.primaryOutput, ports),
      },
    }
    const materialChanged =
      patch.m != null && node.data.ports.find((p) => p.id === portId)?.m !== patch.m
    set({
      nodes: get().nodes.map((n) => (n.id === id ? next : n)),
      edges: materialChanged
        ? get().edges.filter(
            (e) =>
              !(e.source === id && e.sourceHandle === portId) &&
              !(e.target === id && e.targetHandle === portId),
          )
        : get().edges,
    })
  },

  addPort: (id, dir) => {
    const node = get().nodes.find((n) => n.id === id)
    if (!node) return
    const prefix = dir === 'in' ? 'in' : 'out'
    let i = 0
    while (node.data.ports.some((p) => p.id === `${prefix}-${i}`)) i += 1
    const port: NodePort = {
      id: `${prefix}-${i}`,
      m: dir === 'in' ? 'Water' : 'Oxygen',
      rate: dir === 'in' ? 1000 : 100,
      dir,
    }
    get().patchNode(id, { ports: [...node.data.ports, port], portsCustom: true })
  },

  removePort: (id, portId) => {
    const node = get().nodes.find((n) => n.id === id)
    if (!node) return
    const ports = node.data.ports.filter((p) => p.id !== portId)
    const next: CanvasNode = {
      ...node,
      data: {
        ...node.data,
        ports,
        portsCustom: true,
        primaryOutput: normalizePrimary(node.data.primaryOutput, ports),
      },
    }
    set({
      nodes: get().nodes.map((n) => (n.id === id ? next : n)),
      edges: get().edges.filter(
        (e) =>
          !(e.source === id && e.sourceHandle === portId) &&
          !(e.target === id && e.targetHandle === portId),
      ),
    })
  },

  resetPorts: (id) => {
    const node = get().nodes.find((n) => n.id === id)
    if (!node) return
    const d = node.data
    let ports: NodePort[] | null = null
    if (d.kind === 'building') ports = buildingPorts(d.defId, d.recipeId)
    else if (d.kind === 'plant') ports = plantPorts(d.defId, d.domestic ?? false)
    if (!ports) return
    get().patchNode(
      id,
      { ports, portsCustom: false, primaryOutput: defaultPrimaryOutput(ports) },
      true,
    )
  },

  setDomestic: (id, domestic) => {
    const node = get().nodes.find((n) => n.id === id)
    if (!node || node.data.kind !== 'plant') return
    const ports = plantPorts(node.data.defId, domestic)
    get().patchNode(
      id,
      { domestic, ports, portsCustom: false, primaryOutput: defaultPrimaryOutput(ports) },
      true,
    )
    connectFresh(id, get, set)
  },

  setRole: (id, role) => {
    get().patchNode(id, { role }, true)
    connectFresh(id, get, set)
  },

  deleteNode: (id) => {
    get().snapshot()
    set({
      nodes: get().nodes.filter((n) => n.id !== id),
      edges: get().edges.filter((e) => e.source !== id && e.target !== id),
      inspectorId: get().inspectorId === id ? null : get().inspectorId,
    })
  },

  deleteEdge: (id) => {
    get().snapshot()
    set({ edges: get().edges.filter((e) => e.id !== id) })
  },

  deleteSelection: () => {
    const { nodes, edges, inspectorId } = get()
    const selectedNodes = new Set(nodes.filter((n) => n.selected).map((n) => n.id))
    const selectedEdges = new Set(edges.filter((e) => e.selected).map((e) => e.id))
    if (selectedNodes.size === 0 && selectedEdges.size === 0) return
    get().snapshot()
    set({
      nodes: nodes.filter((n) => !selectedNodes.has(n.id)),
      edges: edges.filter(
        (e) =>
          !selectedEdges.has(e.id) &&
          !selectedNodes.has(e.source) &&
          !selectedNodes.has(e.target),
      ),
      inspectorId: inspectorId && selectedNodes.has(inspectorId) ? null : inspectorId,
    })
  },

  duplicateNode: (id) => {
    const node = get().nodes.find((n) => n.id === id)
    if (!node) return
    get().snapshot()
    const copy: CanvasNode = {
      ...node,
      id: newId('copy'),
      position: { x: node.position.x + 48, y: node.position.y + 48 },
      selected: false,
      data: {
        ...node.data,
        ports: node.data.ports.map((p) => ({ ...p })),
      },
    }
    set({ nodes: [...get().nodes, copy], inspectorId: copy.id })
  },

  setAutoCalc: (v) => set({ autoCalc: v }),
  setActiveCategory: (c) => set({ activeCategory: c }),
  setInspector: (id) => set({ inspectorId: id }),
  setTool: (t) => set({ tool: t }),
  setHelp: (v) => set({ helpOpen: v }),
  setSummary: (v) => set({ summaryOpen: v }),
  setMenu: (v) => set({ menuOpen: v }),

  setTheme: (t) => {
    if (typeof document !== 'undefined') {
      document.documentElement.dataset.theme = t
      try {
        localStorage.setItem('oni-canvas-theme', t)
      } catch {
        // ignore
      }
    }
    set({ theme: t })
  },

  showToast: (text) => {
    if (toastTimer) clearTimeout(toastTimer)
    set({ toast: text })
    toastTimer = setTimeout(() => set({ toast: null }), 2600)
  },

  undo: () => {
    const { past, future, nodes, edges } = get()
    if (past.length === 0) return
    const previous = past[past.length - 1]
    set({
      nodes: previous.nodes,
      edges: previous.edges,
      past: past.slice(0, -1),
      future: [
        { nodes: cloneNodes(nodes), edges: edges.map((e) => ({ ...e })) },
        ...future,
      ].slice(0, 60),
      inspectorId: null,
    })
  },

  redo: () => {
    const { past, future, nodes, edges } = get()
    if (future.length === 0) return
    const next = future[0]
    set({
      nodes: next.nodes,
      edges: next.edges,
      past: [...past, { nodes: cloneNodes(nodes), edges: edges.map((e) => ({ ...e })) }].slice(-60),
      future: future.slice(1),
      inspectorId: null,
    })
  },

  newCanvas: () => {
    get().snapshot()
    set({ nodes: [], edges: [], inspectorId: null })
  },

  loadExample: () => {
    get().snapshot()
    const state = exampleState()
    set({
      nodes: state.nodes,
      edges: state.edges,
      autoCalc: state.autoCalc,
      inspectorId: null,
    })
  },

  loadState: (state, toast) => {
    get().snapshot()
    set({
      nodes: state.nodes,
      edges: state.edges,
      autoCalc: state.autoCalc,
      inspectorId: null,
    })
    if (toast) get().showToast(toast)
  },
}))
