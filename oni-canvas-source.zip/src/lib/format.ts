/** Format a mass flow given in g/s. */
export function formatRate(gps: number, digits = 2): string {
  if (!Number.isFinite(gps)) return '—'
  const abs = Math.abs(gps)
  if (abs >= 1000) {
    const v = gps / 1000
    return `${trim(v, digits)} kg/s`
  }
  if (abs < 0.01) return '0 g/s'
  return `${trim(gps, digits)} g/s`
}

export function toKgPerCycle(gps: number): number {
  return (gps * 600) / 1000
}

export function formatPerCycle(gps: number, digits = 2): string {
  const v = toKgPerCycle(gps)
  return `${trim(v, digits)} kg/周期`
}

export function formatPower(w: number, digits = 0): string {
  if (!Number.isFinite(w)) return '—'
  const abs = Math.abs(w)
  if (abs >= 1000) return `${trim(w / 1000, 2)} kW`
  return `${trim(w, digits)} W`
}

export function formatHeat(kdtu: number): string {
  if (!Number.isFinite(kdtu)) return '—'
  return `${trim(kdtu, 2)} kDTU/s`
}

export function trim(n: number, digits: number): string {
  if (!Number.isFinite(n)) return '—'
  const rounded = Number(n.toFixed(digits))
  return String(rounded)
}

export function signed(n: number, digits = 2): string {
  const v = trim(n, digits)
  return n > 0 ? `+${v}` : v
}

export function formatCount(n: number): string {
  if (!Number.isFinite(n)) return '—'
  if (n === 0) return '0'
  if (Math.abs(n) >= 100) return trim(n, 0)
  if (Math.abs(n) >= 10) return trim(n, 1)
  return trim(n, 2)
}
