import LZString from 'lz-string'
import type { Edge, Node } from '@xyflow/react'
import type { CanvasNodeData, FlowEdgeData } from './types'

export interface SerializedState {
  version: 1
  nodes: Node<CanvasNodeData>[]
  edges: Edge<FlowEdgeData>[]
  autoCalc: boolean
}

const STORAGE_KEY = 'oni-canvas-state-v1'
const SHARE_PREFIX = '#s='

export function serialize(
  nodes: Node<CanvasNodeData>[],
  edges: Edge<FlowEdgeData>[],
  autoCalc: boolean,
): SerializedState {
  return { version: 1, nodes, edges, autoCalc }
}

export function isValidState(value: unknown): value is SerializedState {
  if (!value || typeof value !== 'object') return false
  const state = value as Partial<SerializedState>
  return (
    state.version === 1 &&
    Array.isArray(state.nodes) &&
    Array.isArray(state.edges) &&
    typeof state.autoCalc === 'boolean' &&
    state.nodes.every(
      (n) =>
        n &&
        typeof n === 'object' &&
        typeof (n as Node).id === 'string' &&
        typeof (n as Node).type === 'string' &&
        (n as Node).position &&
        typeof (n as Node).position.x === 'number' &&
        typeof (n as Node).position.y === 'number' &&
        (n as Node<CanvasNodeData>).data &&
        typeof (n as Node<CanvasNodeData>).data.kind === 'string',
    )
  )
}

export function saveLocal(state: SerializedState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  } catch {
    // storage can be unavailable in private mode; silently ignore
  }
}

export function loadLocal(): SerializedState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw)
    return isValidState(parsed) ? parsed : null
  } catch {
    return null
  }
}

export function clearLocal(): void {
  try {
    localStorage.removeItem(STORAGE_KEY)
  } catch {
    // ignore
  }
}

export function encodeShare(state: SerializedState): string {
  const json = JSON.stringify(state)
  return `${location.origin}${location.pathname}${SHARE_PREFIX}${LZString.compressToEncodedURIComponent(json)}`
}

export function decodeShare(hash: string): SerializedState | null {
  try {
    if (!hash.startsWith(SHARE_PREFIX)) return null
    const json = LZString.decompressFromEncodedURIComponent(hash.slice(SHARE_PREFIX.length))
    if (!json) return null
    const parsed = JSON.parse(json)
    return isValidState(parsed) ? parsed : null
  } catch {
    return null
  }
}

export function bootState(): SerializedState | null {
  if (typeof window !== 'undefined' && window.location.hash.startsWith(SHARE_PREFIX)) {
    const shared = decodeShare(window.location.hash)
    if (shared) return shared
  }
  return loadLocal()
}

export function downloadJson(state: SerializedState, filename: string): void {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
