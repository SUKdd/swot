import { useReactFlow } from '@xyflow/react'
import { BoxSelect, Hand, Maximize, Scissors } from 'lucide-react'
import { useApp, type CanvasNode } from '../store'
import type { Tool } from '../lib/types'

const TOOLS: { id: Tool; label: string; icon: typeof Hand; hint: string }[] = [
  { id: 'pan', label: '拖手', icon: Hand, hint: '拖拽平移画布' },
  { id: 'select', label: '框选', icon: BoxSelect, hint: '拖拽框选节点' },
  { id: 'cut', label: '剪刀', icon: Scissors, hint: '点击连线断开' },
]

export function ToolDock() {
  const tool = useApp((s) => s.tool)
  const setTool = useApp((s) => s.setTool)
  const flow = useReactFlow<CanvasNode>()

  return (
    <div className="tool-dock">
      {TOOLS.map((t) => {
        const Icon = t.icon
        return (
          <button
            key={t.id}
            className={`tool-btn ${tool === t.id ? 'active' : ''}`}
            title={`${t.label} · ${t.hint}`}
            aria-label={t.label}
            onClick={() => setTool(t.id)}
          >
            <Icon size={18} />
            <span>{t.label}</span>
          </button>
        )
      })}
      <button
        className="tool-btn"
        title="适应画布"
        aria-label="适应画布"
        onClick={() => flow.fitView({ padding: 0.25, duration: 300 })}
      >
        <Maximize size={18} />
        <span>适应</span>
      </button>
    </div>
  )
}

export function Toast() {
  const toast = useApp((s) => s.toast)
  if (!toast) return null
  return <div className="toast">{toast}</div>
}
