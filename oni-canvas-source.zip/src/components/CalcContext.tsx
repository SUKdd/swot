import { createContext, useContext } from 'react'
import type { CalcResult } from '../lib/calc'

interface CalcContextValue {
  result: CalcResult
  autoCalc: boolean
}

const CalcContext = createContext<CalcContextValue | null>(null)

export const CalcProvider = CalcContext.Provider

export function useCalc(): CalcContextValue {
  const value = useContext(CalcContext)
  if (!value) throw new Error('CalcContext missing')
  return value
}
