import { memo } from 'react'
import { Handle, Position, type NodeProps } from '@xyflow/react'
import { ArrowDownLeft, ArrowUpRight, Sparkles } from 'lucide-react'
import type { CanvasNode } from '../store'
import { useCalc } from '../components/CalcContext'
import { materialColor } from '../components/Icon'
import { materialCategory } from '../lib/data'
import { formatRate, signed } from '../lib/format'

function ElementNodeInner({ data, selected }: NodeProps<CanvasNode>) {
  const { result } = useCalc()
  const cat = materialCategory(data.defId)
  const color = materialColor(cat)
  const role = data.role ?? 'boundary'
  const rate = data.rate ?? 0
  const balance = result.byMaterial[data.defId]
  const net = Math.abs(balance?.net ?? 0) < 0.01 ? 0 : (balance?.net ?? 0)
  const showSupply = role === 'supply'
  const showDemand = role === 'demand'
  const showBoth = role === 'boundary'

  return (
    <div
      className={`element-node ${selected ? 'selected' : ''} ${data.enabled ? '' : 'disabled'}`}
      style={{ ['--mat-color' as string]: color }}
    >
      {showBoth && (
        <Handle type="target" position={Position.Left} id="in" className="port-handle" style={{ borderColor: color }} />
      )}
      {showDemand && (
        <Handle type="target" position={Position.Left} id="in" className="port-handle" style={{ borderColor: color }} />
      )}
      {showBoth && (
        <Handle type="source" position={Position.Right} id="out" className="port-handle" style={{ borderColor: color }} />
      )}
      {showSupply && (
        <Handle type="source" position={Position.Right} id="out" className="port-handle" style={{ borderColor: color }} />
      )}

      <div className="element-title">
        <span className="element-dot" />
        <span className="element-name">{data.name}</span>
        <span className={`role-pill ${role}`}>
          {role === 'supply' ? (
            <>
              <ArrowUpRight size={10} /> 供给
            </>
          ) : role === 'demand' ? (
            <>
              <ArrowDownLeft size={10} /> 需求
            </>
          ) : (
            <>平衡</>
          )}
        </span>
      </div>
      <div className="element-rate">
        {role === 'boundary' ? (
          <span className={net < 0 ? 'neg' : net > 0 ? 'pos' : ''}>{signed(net, 2)} g/s</span>
        ) : (
          <span>{formatRate(rate)}</span>
        )}
      </div>
      <div className="element-sub">
        {role === 'boundary' ? '全域净流量' : role === 'supply' ? '外部供给上限' : '外部需求下限'}
        {data.temp != null && ` · ${data.temp}°C`}
      </div>
      {data.auto && (
        <div className="element-auto">
          <Sparkles size={10} /> 自动
        </div>
      )}
    </div>
  )
}

export const ElementNode = memo(ElementNodeInner)
