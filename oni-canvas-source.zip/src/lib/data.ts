import materialsJson from '../data/materials.json'
import buildingsJson from '../data/buildings.json'
import recipesJson from '../data/recipes.json'
import plantsJson from '../data/plants.json'
import crittersJson from '../data/critters.json'
import foodsJson from '../data/foods.json'
import geysersJson from '../data/geysers.json'
import itemsJson from '../data/items.json'
import type {
  Building,
  CategoryId,
  Critter,
  Food,
  Geyser,
  Item,
  Material,
  Plant,
  Recipe,
} from './types'

export const materials = materialsJson as Material[]
export const buildings = buildingsJson as Building[]
export const recipes = recipesJson as Recipe[]
export const plants = plantsJson as Plant[]
export const critters = crittersJson as Critter[]
export const foods = foodsJson as Food[]
export const geysers = geysersJson as Geyser[]
export const items = itemsJson as Item[]

export const materialById = new Map(materials.map((m) => [m.id, m]))
export const buildingById = new Map(buildings.map((b) => [b.id, b]))
export const recipeById = new Map(recipes.map((r) => [r.id, r]))
export const plantById = new Map(plants.map((p) => [p.id, p]))
export const critterById = new Map(critters.map((c) => [c.id, c]))
export const foodById = new Map(foods.map((f) => [f.id, f]))
export const geyserById = new Map(geysers.map((g) => [g.id, g]))
export const itemById = new Map(items.map((i) => [i.id, i]))

export const recipesByFab = new Map<string, Recipe[]>()
for (const r of recipes) {
  const list = recipesByFab.get(r.fab) ?? []
  list.push(r)
  recipesByFab.set(r.fab, list)
}
for (const list of recipesByFab.values()) {
  list.sort((a, b) => a.id.localeCompare(b.id))
}

export const rocketBuildings = buildings.filter((b) => b.cat === '火箭')
export const solidMaterials = materials.filter((m) => m.cat === 'solid')
export const liquidMaterials = materials.filter((m) => m.cat === 'liquid')
export const gasMaterials = materials.filter((m) => m.cat === 'gas')

export const buildingCategories = Array.from(new Set(buildings.map((b) => b.cat))).sort(
  (a, b) => a.localeCompare(b, 'zh-CN'),
)

export function materialName(id: string | null | undefined): string {
  if (!id) return '—'
  return materialById.get(id)?.name ?? id.replace(/([a-z])([A-Z])/g, '$1 $2')
}

export function materialCategory(id: string | null | undefined): Material['cat'] {
  if (!id) return 'other'
  return materialById.get(id)?.cat ?? 'other'
}

export interface CategoryMeta {
  id: CategoryId
  label: string
  short: string
  count: number
}

export const CATEGORY_LIST: CategoryMeta[] = [
  { id: 'buildings', label: '建筑', short: '建筑', count: buildings.length },
  { id: 'solids', label: '固体', short: '固体', count: solidMaterials.length },
  { id: 'liquids', label: '液体', short: '液体', count: liquidMaterials.length },
  { id: 'gases', label: '气体', short: '气体', count: gasMaterials.length },
  { id: 'critters', label: '小动物', short: '小动物', count: critters.length },
  { id: 'plants', label: '植物', short: '植物', count: plants.length },
  { id: 'foods', label: '食物', short: '食物', count: foods.length },
  { id: 'items', label: '物品', short: '物品', count: items.length },
  { id: 'duplicants', label: '复制人', short: '复制人', count: 1 },
  { id: 'geysers', label: '间歇泉', short: '间歇泉', count: geysers.length },
  { id: 'rockets', label: '火箭', short: '火箭', count: rocketBuildings.length },
  { id: 'systems', label: '系统', short: '系统', count: 4 },
]

export const SUMMARY_MATERIALS = ['Oxygen', 'Water', 'Hydrogen', 'CarbonDioxide', 'DirtyWater', 'Carbon']
